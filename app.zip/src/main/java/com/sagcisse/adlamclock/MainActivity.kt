package com.sagcisse.adlamclock

import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var isClockVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rootView = window.decorView.findViewById<ViewGroup>(android.R.id.content)
        val calendarView = findViewById<FulfuldeCalendar>(R.id.fulfuldeCalendar)
        val clockView = findViewById<AdlamClockView>(R.id.adlamClockView)
        val btnShowClock = findViewById<Button>(R.id.btn_show_clock)
        val btnSetWallpaper = findViewById<Button?>(R.id.btn_set_wallpaper)
        val btnSelectBg = findViewById<Button?>(R.id.btn_select_bg)
        val btnClockStyle = findViewById<Button?>(R.id.btn_clock_style)

        // 1. تطبيق خلفية الشاشة باللون الداكن
        rootView.setBackgroundColor(Color.parseColor("#0F1218"))

        // 2. تطبيق خط الأدلام على واجهة النشاط الرئيسية
        val adlamFont = FontLoader.getTypeface(this) ?: Typeface.DEFAULT
        applyFontToViewTree(rootView, adlamFont)

        // 3. تنسيق الأزرار
        styleActionButton(btnShowClock)
        btnSetWallpaper?.let { styleActionButton(it) }
        btnSelectBg?.let { styleActionButton(it) }
        btnClockStyle?.let { styleActionButton(it) }

        startClockService()

        btnShowClock.setOnClickListener {
            isClockVisible = !isClockVisible
            if (isClockVisible) {
                calendarView.visibility = View.GONE
                clockView.visibility = View.VISIBLE
                btnShowClock.text = "𞤙𞤢𞤤𞤯𞤭𞤥𞤫𞤪𞤫 𞤊𞤵𞤤𞤬𞤵𞤤𞤣𞤫 📅"
            } else {
                clockView.visibility = View.GONE
                calendarView.visibility = View.VISIBLE
                btnShowClock.text = "𞤀𞤺𞤮𞥅𞤺𞤮 𞤊𞤵𞤤𞤬𞤵𞤤𞤣𞤫 🕒"
            }
        }

        btnSetWallpaper?.setOnClickListener {
            openLiveWallpaperPicker()
        }

        btnSelectBg?.setOnClickListener {
            val intent = Intent(this, WallpaperGalleryActivity::class.java)
            startActivity(intent)
        }

        btnClockStyle?.setOnClickListener {
            showClockStyleDialog()
        }
    }

    private fun showClockStyleDialog() {
        val styles = arrayOf(
            "𞤢𞤺𞤮𞥅𞤺𞤮 (𞤃𞤢𞤰𞥆𞤮𞥅𞤱𞤮)",
            "𞤀𞤺𞤮𞥅𞤺𞤮  (𞤒𞤭𞤤𞤼𞤮𞤼𞤮𞥅𞤯𞤮)",
            "𞤀𞤺𞤮𞥅𞤺𞤮 (𞤍𞤭𞤯𞤭 𞤊𞤵𞤤)"
        )

        val dialog = AlertDialog.Builder(this)
            .setTitle("𞤅𞤵𞤩𞤢 𞤐𞤢𞤼𞤢𞤤 𞤖𞤫𞤤𞥆𞤮 𞤅𞤮𞤳𞤢𞤺𞤮𞤤")
            .setItems(styles) { _, which ->
                val styleValue = when (which) {
                    0 -> 1
                    1 -> 0
                    else -> 2
                }
                getSharedPreferences("adlam_clock_prefs", Context.MODE_PRIVATE)
                    .edit().putInt("wallpaper_clock_style", styleValue).apply()
                Toast.makeText(this, "𞤐𞤮𞥅𞤲𞤫 𞤐𞤣𞤫𞤲 𞤏𞤢𞤴𞤤𞤭𞥅𞤥𞤢", Toast.LENGTH_SHORT).show()
            }
            .create()

        dialog.show()

        // تطبيق الخط على عناصر النافذة
        applyFontToDialog(dialog)
    }

    private fun applyFontToDialog(dialog: AlertDialog) {
        val font = FontLoader.getTypeface(this) ?: return

        // 1. تطبيق الخط على عنوان النافذة (Title)
        val titleId = resources.getIdentifier("alertTitle", "id", "android")
        dialog.findViewById<TextView>(titleId)?.typeface = font

        // 2. تطبيق الخط على أزرار النافذة إن وجدت
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.typeface = font
        dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.typeface = font

        // 3. تطبيق الخط على خيارات القائمة
        dialog.listView?.post {
            val listView = dialog.listView
            for (i in 0 until listView.childCount) {
                val itemView = listView.getChildAt(i)
                if (itemView is TextView) {
                    itemView.typeface = font
                }
            }
        }
    }

    fun openLiveWallpaperPicker() {
        try {
            val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(this@MainActivity, AdlamClockWallpaperService::class.java)
                )
            }
            startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "𞤏𞤮𞤲 𞤕𞤢𞤯𞤫𞥅𞤤𞤫 ", Toast.LENGTH_SHORT).show()
        }
    }

    private fun styleActionButton(button: Button) {
        val buttonDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 30f
            setColor(Color.argb(160, 25, 30, 40))
            setStroke(3, Color.rgb(220, 180, 70))
        }

        button.background = buttonDrawable
        button.setTextColor(Color.rgb(245, 220, 140))
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        button.setPadding(32, 16, 32, 16)
    }

    private fun applyFontToViewTree(view: View, typeface: Typeface) {
        if (view is TextView) {
            view.typeface = typeface
        } else if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                applyFontToViewTree(view.getChildAt(i), typeface)
            }
        }
    }

    private fun startClockService() {
        try {
            val intent = Intent(this, ClockService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
