package com.sagcisse.adlamclock

import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.View
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class AdlamClockView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        isSubpixelText = true
    }

    private val handler = Handler(Looper.getMainLooper())

    private val clockRunnable = object : Runnable {
        override fun run() {
            invalidate()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        handler.post(clockRunnable)
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(clockRunnable)
        super.onDetachedFromWindow()
    }

    companion object {
        private val clockNumbers = arrayOf("𞥑𞥒", "𞥑", "𞥒", "𞥓", "𞥔", "𞥕", "𞥖", "𞥗", "𞥘", "𞥙", "𞥑𞥐", "𞥑𞥑")

        private val days = arrayOf(
            "𞤁𞤫𞤱𞤮",       // الأحد
            "𞤀𞥄𞤩𞤲𞤣𞤫",     // الاثنين
            "𞤃𞤢𞤱𞤦𞤢𞥄𞤪𞤫",   // الثلاثاء
            "𞤐𞤶𞤫𞤧𞤤𞤢𞥄𞤪𞤫",  // الأربعاء
            "𞤐𞤢𞥄𞤧𞤢𞥄𞤲𞤣𞤫",  // الخميس
            "𞤃𞤢𞤱𞤲'𞤣𞤫",    // الجمعة
            "𞤖𞤮𞤪𞤦𞤭𞤪𞥆𞤫"    // السبت
        )

        private val months = arrayOf(
            "𞤅𞤭𞥅𞤤𞤮",  // يناير
            "𞤕𞤮𞤤𞤼𞤮",  // فبراير
            "𞤐𞤄𞤮𞥅𞤴𞤮", // مارس
            "𞤅𞤫𞤯𞤼𞤮",  // أبريل
            "𞤁𞤵𞥅𞤶𞤮",  // مايو
            "𞤑𞤮𞤪𞤧𞤮",  // يونيو
            "𞤃𞤮𞤪𞤧𞤮",  // يوليو
            "𞤔𞤵𞤳𞤮",   // أغسطس
            "𞤅𞤭𞤤𞤼𞤮",  // سبتمبر
            "𞤒𞤢𞤪𞤳𞤮",  // أكتوبر
            "𞤔𞤮𞤤𞤮",   // نوفمبر
            "𞤄𞤮𞤱𞤼𞤮"   // ديسمبر
        )

        private fun toAdlam(number: Int): String {
            return number.toString()
                .replace("0", "𞥐").replace("1", "𞥑").replace("2", "𞥒")
                .replace("3", "𞥓").replace("4", "𞥔").replace("5", "𞥕")
                .replace("6", "𞥖").replace("7", "𞥗").replace("8", "𞥘").replace("9", "𞥙")
        }

        private fun twoDigits(number: Int): String {
            return if (number < 10) "𞥐" + toAdlam(number) else toAdlam(number)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // تطبيق خط الأدلام الموحد عبر FontLoader
        paint.typeface = FontLoader.getTypeface(context)

        val prefs = context.getSharedPreferences("adlam_clock_prefs", Context.MODE_PRIVATE)
        val themeIndex = prefs.getInt("theme_index", 0)

        // ألوان الثيمات المتوافقة مع الخدمة
        val cardBg = Color.argb(255, 15, 18, 24)
        val cardBorder = Color.argb(120, 255, 255, 255)
        val dialBg = Color.argb(255, 20, 24, 33)
        val dialBorder = Color.rgb(180, 180, 180)
        val handsColor = Color.WHITE
        val secondHandColor = Color.rgb(255, 60, 60)
        val textColor = Color.WHITE
        val subTextColor = Color.rgb(220, 220, 220)
        val tickColor = Color.argb(160, 255, 255, 255)

        val calendar = Calendar.getInstance(TimeZone.getDefault())
        val hour24 = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)
        val second = calendar.get(Calendar.SECOND)

        val centerX = w / 2f
        val centerY = h / 2f
        val smallest = min(w, h)

        // 1. خلفية البطاقة
        val cardPadding = smallest * 0.03f
        val cardRadius = smallest * 0.12f
        paint.style = Paint.Style.FILL
        paint.color = cardBg
        canvas.drawRoundRect(cardPadding, cardPadding, w - cardPadding, h - cardPadding, cardRadius, cardRadius, paint)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = cardBorder
        canvas.drawRoundRect(cardPadding, cardPadding, w - cardPadding, h - cardPadding, cardRadius, cardRadius, paint)

        // 2. قرص الساعة الداخلي
        val radius = smallest * 0.38f
        val clockCenterX = centerX
        val clockCenterY = centerY - smallest * 0.02f

        paint.style = Paint.Style.FILL
        paint.color = dialBg
        canvas.drawCircle(clockCenterX, clockCenterY, radius, paint)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        paint.color = dialBorder
        canvas.drawCircle(clockCenterX, clockCenterY, radius, paint)

        // 3. علامات الساعات والدقائق
        for (i in 0 until 60) {
            val angle = Math.PI * 2.0 * i / 60.0 - Math.PI / 2.0
            val isHourTick = (i % 5 == 0)

            val innerR = if (isHourTick) radius * 0.85f else radius * 0.92f
            val outerR = radius * 0.96f

            paint.strokeWidth = if (isHourTick) 3.5f else 1.5f
            paint.color = if (isHourTick) textColor else tickColor

            val startX = clockCenterX + cos(angle).toFloat() * innerR
            val startY = clockCenterY + sin(angle).toFloat() * innerR
            val endX = clockCenterX + cos(angle).toFloat() * outerR
            val endY = clockCenterY + sin(angle).toFloat() * outerR

            canvas.drawLine(startX, startY, endX, endY, paint)
        }

        // 4. أرقام الساعة
        paint.style = Paint.Style.FILL
        paint.color = textColor
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = radius * 0.22f
        paint.isFakeBoldText = true

        for (i in 0 until 12) {
            val angle = Math.PI * 2.0 * i / 12.0 - Math.PI / 2.0
            val numR = radius * 0.70f
            val x = clockCenterX + cos(angle).toFloat() * numR
            val y = clockCenterY + sin(angle).toFloat() * numR - (paint.ascent() + paint.descent()) / 2f
            canvas.drawText(clockNumbers[i], x, y, paint)
        }

        // 5. الوقت الرقمي
        val digitalTime = "\u200E${twoDigits(hour24)}:${twoDigits(minute)}:${twoDigits(second)}"
        paint.textSize = radius * 0.16f
        paint.isFakeBoldText = false
        paint.color = subTextColor
        canvas.drawText(digitalTime, clockCenterX, clockCenterY - radius * 0.35f, paint)

        // 6. دائرة اليوم في منتصف القرص
        val dayCircleRadius = radius * 0.22f
        val dayCircleY = clockCenterY + radius * 0.35f
        paint.style = Paint.Style.FILL
        paint.color = cardBg
        canvas.drawCircle(clockCenterX, dayCircleY, dayCircleRadius, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        paint.color = dialBorder
        canvas.drawCircle(clockCenterX, dayCircleY, dayCircleRadius, paint)

        // اسم اليوم داخل الدائرة
        val dayIndex = calendar.get(Calendar.DAY_OF_WEEK) - 1
        paint.style = Paint.Style.FILL
        paint.textSize = radius * 0.11f
        paint.isFakeBoldText = true
        paint.color = textColor
        val dayY = dayCircleY - (paint.ascent() + paint.descent()) / 2f
        canvas.drawText(days[dayIndex], clockCenterX, dayY, paint)

        // 7. العقارب
        val hour12 = calendar.get(Calendar.HOUR)
        val hourAngle = Math.PI / 6.0 * (hour12 + minute / 60.0) - Math.PI / 2.0
        drawHand(canvas, clockCenterX, clockCenterY, hourAngle, radius * 0.45f, 8f, handsColor, true)

        val minuteAngle = Math.PI / 30.0 * (minute + second / 60.0) - Math.PI / 2.0
        drawHand(canvas, clockCenterX, clockCenterY, minuteAngle, radius * 0.65f, 5f, handsColor, true)

        val secondAngle = Math.PI / 30.0 * second - Math.PI / 2.0
        drawHand(canvas, clockCenterX, clockCenterY, secondAngle, radius * 0.80f, 2.5f, secondHandColor, true)

        // نقطة المنتصف
        paint.style = Paint.Style.FILL
        paint.color = secondHandColor
        canvas.drawCircle(clockCenterX, clockCenterY, radius * 0.05f, paint)
        paint.color = Color.WHITE
        canvas.drawCircle(clockCenterX, clockCenterY, radius * 0.02f, paint)

        // 8. التاريخ الكامل أسفل البطاقة
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val month = calendar.get(Calendar.MONTH)
        val year = calendar.get(Calendar.YEAR)
        val dateText = "${toAdlam(day)} ${months[month]} ${toAdlam(year)}"

        paint.textSize = radius * 0.13f
        paint.isFakeBoldText = true
        paint.color = textColor
        canvas.drawText(dateText, clockCenterX, h - cardPadding - smallest * 0.04f, paint)
    }

    private fun drawHand(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        angle: Double,
        length: Float,
        thickness: Float,
        color: Int,
        hasTail: Boolean = false
    ) {
        paint.style = Paint.Style.STROKE
        paint.color = color
        paint.strokeWidth = thickness
        paint.strokeCap = Paint.Cap.ROUND

        val endX = cx + cos(angle).toFloat() * length
        val endY = cy + sin(angle).toFloat() * length

        if (hasTail) {
            val tailLength = length * 0.18f
            val startX = cx - cos(angle).toFloat() * tailLength
            val startY = cy - sin(angle).toFloat() * tailLength
            canvas.drawLine(startX, startY, endX, endY, paint)
        } else {
            canvas.drawLine(cx, cy, endX, endY, paint)
        }
    }
}
