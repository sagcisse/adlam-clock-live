package com.sagcisse.adlamclock

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class WallpaperPreviewActivity : AppCompatActivity() {

    private var resId: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wallpaper_preview)

        resId = intent.getIntExtra("selected_res_id", 0)

        val imgBackground = findViewById<ImageView>(R.id.imgPreviewBg)
        val btnApplyWithClock = findViewById<Button>(R.id.btnApplyWithClock)
        val btnApplyImageOnly = findViewById<Button>(R.id.btnApplyImageOnly)
        val btnApplyClockTransparent = findViewById<Button>(R.id.btnApplyClockTransparent)

        if (resId != 0 && resId != -1) {
            imgBackground.setImageResource(resId)
        } else {
            imgBackground.setBackgroundColor(Color.parseColor("#0F1218"))
        }

        val prefs = getSharedPreferences("adlam_clock_prefs", Context.MODE_PRIVATE)

        // 1. تطبيق الخلفية + الساعة
        btnApplyWithClock.setOnClickListener {
            prefs.edit().putInt("selected_bg_res_id", resId).apply()
            // إعادة ضبط نمط الساعة للرقمية إذا كانت معطلة
            if (prefs.getInt("wallpaper_clock_style", 1) == 3) {
                prefs.edit().putInt("wallpaper_clock_style", 1).apply()
            }
            openLiveWallpaperPicker()
        }

        // 2. تطبيق الصورة كخلفية فقط (بدون ساعة)
        btnApplyImageOnly.setOnClickListener {
            prefs.edit().putInt("selected_bg_res_id", resId).apply()
            prefs.edit().putInt("wallpaper_clock_style", 3).apply() // 3 = بدون ساعة
            openLiveWallpaperPicker()
        }

        // 3. تطبيق الساعة كخلفية شفافة (ساعة فقط بدون تغيير الخلفية)
        btnApplyClockTransparent.setOnClickListener {
            prefs.edit().putInt("selected_bg_res_id", -1).apply() // -1 = خلفية شفافة
            if (prefs.getInt("wallpaper_clock_style", 1) == 3) {
                prefs.edit().putInt("wallpaper_clock_style", 1).apply()
            }
            openLiveWallpaperPicker()
        }
    }

    private fun openLiveWallpaperPicker() {
        try {
            val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(this@WallpaperPreviewActivity, AdlamClockWallpaperService::class.java)
                )
            }
            startActivity(intent)
            finish()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "𞤏𞤮𞤲 𞤕𞤢𞤯𞤫𞥅𞤤𞤫", Toast.LENGTH_SHORT).show()
        }
    }
}
