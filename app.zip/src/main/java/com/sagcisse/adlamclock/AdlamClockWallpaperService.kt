package com.sagcisse.adlamclock

import android.app.KeyguardManager
import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class AdlamClockWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine {
        return ClockEngine()
    }

    inner class ClockEngine : Engine() {

        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private var bgBitmap: Bitmap? = null
        private var themeIndex = 0
        private var clockStyle = 1 // 0: تناظرية، 1: رقمية، 2: مزدوجة، 3: بدون ساعة
        private var clockScale = 1.0f

        private val drawRunnable = Runnable {
            draw()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            if (visible) {
                loadUserPreferences()
                handler.post(drawRunnable)
            } else {
                handler.removeCallbacks(drawRunnable)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder?) {
            super.onSurfaceDestroyed(holder)
            this.visible = false
            handler.removeCallbacks(drawRunnable)
            bgBitmap?.recycle()
            bgBitmap = null
        }

        override fun onTouchEvent(event: MotionEvent?) {
            if (event?.action == MotionEvent.ACTION_DOWN) {
                if (clockStyle != 3) {
                    themeIndex = (themeIndex + 1) % ClockService.themes.size
                    val prefs = getSharedPreferences("adlam_clock_prefs", Context.MODE_PRIVATE)
                    prefs.edit().putInt("wallpaper_theme_index", themeIndex).apply()
                    draw()
                }
            }
            super.onTouchEvent(event)
        }

        private fun loadUserPreferences() {
            val prefs = getSharedPreferences("adlam_clock_prefs", Context.MODE_PRIVATE)
            val bgResId = prefs.getInt("selected_bg_res_id", 0)
            themeIndex = prefs.getInt("wallpaper_theme_index", 0).coerceIn(0, ClockService.themes.lastIndex)
            clockStyle = prefs.getInt("wallpaper_clock_style", 1)

            val scalePercent = prefs.getInt("wallpaper_clock_scale", 100)
            clockScale = (scalePercent / 100f).coerceIn(0.4f, 1.6f)

            if (bgResId > 0) {
                try {
                    bgBitmap = BitmapFactory.decodeResource(resources, bgResId)
                } catch (e: Exception) {
                    e.printStackTrace()
                    bgBitmap = fetchSystemWallpaper()
                }
            } else {
                // جلب خلفية جهاز المستخدم الحالية لمنع ظهور اللون الأسود
                bgBitmap = fetchSystemWallpaper()
            }
        }

        /**
         * جلب خلفية جهاز المستخدم الأصلية تلقائياً من نظام أندرويد
         */
        private fun fetchSystemWallpaper(): Bitmap? {
            return try {
                val wm = WallpaperManager.getInstance(applicationContext)
                val drawable: Drawable? = wm.drawable
                if (drawable != null) {
                    val w = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 1080
                    val h = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 1920
                    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(bitmap)
                    drawable.setBounds(0, 0, w, h)
                    drawable.draw(canvas)
                    bitmap
                } else null
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }

        private fun draw() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    drawWallpaperContent(canvas)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }

            handler.removeCallbacks(drawRunnable)
            if (visible) {
                handler.postDelayed(drawRunnable, 1000L)
            }
        }

        private fun drawWallpaperContent(canvas: Canvas) {
            val w = canvas.width.toFloat()
            val h = canvas.height.toFloat()

            // 1. رسم خلفية صورة التطبيق أو صورة جهاز المستخدم الحالية
            if (bgBitmap != null && !bgBitmap!!.isRecycled) {
                val srcRect = Rect(0, 0, bgBitmap!!.width, bgBitmap!!.height)
                val destRect = Rect(0, 0, w.toInt(), h.toInt())
                canvas.drawBitmap(bgBitmap!!, srcRect, destRect, null)
            } else {
                canvas.drawColor(Color.parseColor("#0F1218"))
            }

            if (clockStyle == 3) {
                return
            }

            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            val isLocked = keyguardManager.isKeyguardLocked

            if (!isLocked && isPreview == false) {
                return
            }

            val theme = ClockService.themes[themeIndex]
            val smallest = min(w, h)
            val cx = w / 2f
            val cy = h * 0.18f

            val effectiveSmallest = smallest * 0.65f * clockScale

            when (clockStyle) {
                0 -> drawAnalogClock(canvas, cx, cy, effectiveSmallest, theme)
                1 -> drawDigitalClock(canvas, cx, cy, effectiveSmallest, theme)
                2 -> {
                    drawAnalogClock(canvas, cx, cy - effectiveSmallest * 0.15f, effectiveSmallest * 0.70f, theme)
                    drawDigitalClock(canvas, cx, cy + effectiveSmallest * 0.25f, effectiveSmallest * 0.70f, theme)
                }
            }
        }

        private fun drawDigitalClock(
            canvas: Canvas,
            cx: Float,
            cy: Float,
            smallest: Float,
            theme: ClockService.Companion.ColorTheme
        ) {
            val calendar = Calendar.getInstance(TimeZone.getDefault())
            val hour24 = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)

            val timeStr = String.format(Locale.US, "%02d:%02d", hour24, minute)
            val adlamTime = toAdlam(timeStr)
            val font = FontLoader.getTypeface(applicationContext)

            val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textAlign = Paint.Align.CENTER
                color = theme.numbersText
                typeface = font
                textSize = smallest * 0.22f
            }

            canvas.save()
            val timeY = cy
            canvas.scale(0.80f, 1.40f, cx, timeY)
            canvas.drawText(adlamTime, cx, timeY, timePaint)
            canvas.restore()

            val weekday = getWeekdayAdlam(calendar.get(Calendar.DAY_OF_WEEK))
            val day = calendar.get(Calendar.DAY_OF_MONTH)
            val month = calendar.get(Calendar.MONTH)
            val year = calendar.get(Calendar.YEAR)
            val dateText = "$weekday ${toAdlam(day.toString())} ${getMonthAdlam(month)} ${toAdlam(year.toString())}"

            val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textAlign = Paint.Align.CENTER
                color = if (theme.ticks != Color.TRANSPARENT) theme.ticks else theme.numbersText
                typeface = font
                textSize = smallest * 0.052f
                alpha = 220
            }

            canvas.drawText(dateText, cx, cy + smallest * 0.13f, datePaint)
        }

        private fun drawAnalogClock(
            canvas: Canvas,
            cx: Float,
            cy: Float,
            smallest: Float,
            theme: ClockService.Companion.ColorTheme
        ) {
            val radius = smallest * 0.26f
            val font = FontLoader.getTypeface(applicationContext)

            val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                color = if (theme.widgetBorder != Color.TRANSPARENT) theme.widgetBorder else theme.hourMinHand
                strokeWidth = smallest * 0.006f
            }
            canvas.drawCircle(cx, cy, radius, borderPaint)

            val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = theme.ticks
                strokeCap = Paint.Cap.ROUND
            }

            for (i in 0 until 60) {
                val angle = Math.toRadians((i * 6.0) - 90.0)
                val isHour = i % 5 == 0
                val innerR = if (isHour) radius * 0.88f else radius * 0.94f
                val outerR = radius * 0.97f

                tickPaint.strokeWidth = if (isHour) smallest * 0.008f else smallest * 0.003f

                val startX = cx + cos(angle).toFloat() * innerR
                val startY = cy + sin(angle).toFloat() * innerR
                val stopX = cx + cos(angle).toFloat() * outerR
                val stopY = cy + sin(angle).toFloat() * outerR

                canvas.drawLine(startX, startY, stopX, stopY, tickPaint)
            }

            val numberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textAlign = Paint.Align.CENTER
                color = theme.numbersText
                typeface = font
                textSize = smallest * 0.065f
            }

            val numbers = arrayOf("12", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11")
            for (i in 0 until 12) {
                val angle = Math.toRadians((i * 30.0) - 90.0)
                val x = cx + cos(angle).toFloat() * radius * 0.72f
                val y = cy + sin(angle).toFloat() * radius * 0.72f - (numberPaint.ascent() + numberPaint.descent()) / 2f
                canvas.drawText(toAdlam(numbers[i]), x, y, numberPaint)
            }

            val calendar = Calendar.getInstance(TimeZone.getDefault())
            val hour24 = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)
            val second = calendar.get(Calendar.SECOND)

            val hourAngle = ((hour24 % 12) * 30f) + (minute * 0.5f)
            val minuteAngle = minute * 6f + second * 0.1f
            val secondAngle = second * 6f

            drawHand(canvas, cx, cy, radius * 0.48f, hourAngle, smallest * 0.015f, theme.hourMinHand)
            drawHand(canvas, cx, cy, radius * 0.70f, minuteAngle, smallest * 0.010f, theme.hourMinHand)
            drawHand(canvas, cx, cy, radius * 0.82f, secondAngle, smallest * 0.004f, theme.secondHand)

            val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = theme.centerCap
            }
            canvas.drawCircle(cx, cy, smallest * 0.015f, centerPaint)
        }

        private fun drawHand(
            canvas: Canvas,
            cx: Float,
            cy: Float,
            length: Float,
            angle: Float,
            strokeWidth: Float,
            color: Int
        ) {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                this.strokeWidth = strokeWidth
                this.color = color
            }
            val radians = Math.toRadians((angle - 90f).toDouble())
            val x = cx + cos(radians).toFloat() * length
            val y = cy + sin(radians).toFloat() * length
            canvas.drawLine(cx, cy, x, y, paint)
        }

        private fun getWeekdayAdlam(day: Int): String {
            return when (day) {
                Calendar.SUNDAY -> "𞤁𞤫𞤱𞤮"
                Calendar.MONDAY -> "𞤀𞥄𞤩𞤲𞤣𞤫"
                Calendar.TUESDAY -> "𞤃𞤢𞤱𞤦𞤢𞥄𞤪𞤫"
                Calendar.WEDNESDAY -> "𞤐𞤶𞤫𞤧𞤤𞤢𞥄𞤪𞤫"
                Calendar.THURSDAY -> "𞤐𞤢𞥄𞤧𞤢𞥄𞤲𞤣𞤫"
                Calendar.FRIDAY -> "𞤃𞤢𞤱𞤲'𞤣𞤫"
                Calendar.SATURDAY -> "𞤖𞤮𞤪𞤦𞤭𞤪𞥆𞤫"
                else -> ""
            }
        }

        private fun getMonthAdlam(month: Int): String {
            return when (month) {
                Calendar.JANUARY -> "𞤅𞤭𞥅𞤤𞤮"
                Calendar.FEBRUARY -> "𞤕𞤮𞤤𞤼𞤮"
                Calendar.MARCH -> "𞤐𞤄𞤮𞥅𞤴𞤮"
                Calendar.APRIL -> "𞤅𞤫𞤯𞤼𞤮"
                Calendar.MAY -> "𞤁𞤵𞥅𞤶𞤮"
                Calendar.JUNE -> "𞤑𞤮𞤪𞤧𞤮"
                Calendar.JULY -> "𞤃𞤮𞤪𞤧𞤮"
                Calendar.AUGUST -> "𞤔𞤵𞤳𞤮"
                Calendar.SEPTEMBER -> "𞤅𞤭𞤤𞤼𞤮"
                Calendar.OCTOBER -> "𞤒𞤢𞤪𞤳𞤮"
                Calendar.NOVEMBER -> "𞤔𞤮𞤤𞤮"
                Calendar.DECEMBER -> "𞤄𞤮𞤱𞤼𞤮"
                else -> ""
            }
        }

        private fun toAdlam(value: String): String {
            return value
                .replace("0", "𞥐").replace("1", "𞥑").replace("2", "𞥒")
                .replace("3", "𞥓").replace("4", "𞥔").replace("5", "𞥕")
                .replace("6", "𞥖").replace("7", "𞥗").replace("8", "𞥘").replace("9", "𞥙")
                .replace("٠", "𞥐").replace("١", "𞥑").replace("٢", "𞥒")
                .replace("٣", "𞥓").replace("٤", "𞥔").replace("٥", "𞥕")
                .replace("٦", "𞥖").replace("٧", "𞥗").replace("٨", "𞥘").replace("٩", "𞥙")
        }
    }
}
