package com.sagcisse.adlamclock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

class ClockService : Service() {

    private val handler = Handler(Looper.getMainLooper())

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF,
                Intent.ACTION_SCREEN_ON,
                Intent.ACTION_TIMEZONE_CHANGED,
                Intent.ACTION_TIME_CHANGED -> {
                    updateAllWidgets()
                }
            }
        }
    }

    private val updateRunnable = object : Runnable {
        override fun run() {
            updateAllWidgets()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()

        createNotificationChannel(this)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    createNotification(this),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    createNotification(this),
                    0
                )
            } else {
                startForeground(
                    NOTIFICATION_ID,
                    createNotification(this)
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_TIMEZONE_CHANGED)
                addAction(Intent.ACTION_TIME_CHANGED)
            }

            ContextCompat.registerReceiver(
                this,
                screenReceiver,
                filter,
                ContextCompat.RECEIVER_EXPORTED
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }

        handler.post(updateRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CYCLE_THEME) {
            val appWidgetId = intent.getIntExtra(
                AppWidgetManager.EXTRA_APPWIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID
            )

            if (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                cycleThemeIndex(this, appWidgetId)
            }
        }

        updateAllWidgets()
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(updateRunnable)
        try {
            unregisterReceiver(screenReceiver)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun updateAllWidgets() {
        updateAllWidgets(this)
    }

    companion object {

        const val ACTION_CYCLE_THEME = "com.sagcisse.adlamclock.ACTION_CYCLE_THEME"
        private const val CHANNEL_ID = "adlam_clock_service"
        private const val NOTIFICATION_ID = 1001

        data class ColorTheme(
            val ticks: Int,
            val numbersText: Int,
            val digitalTimeText: Int,
            val infoText: Int,
            val hourMinHand: Int,
            val secondHand: Int,
            val centerCap: Int,
            val background: Int = Color.TRANSPARENT,
            val dialBg: Int = Color.TRANSPARENT,
            val dialBorder: Int = Color.WHITE,
            val widgetBackground: Int = Color.TRANSPARENT,
            val widgetBorder: Int = Color.TRANSPARENT,
            val widgetBorderWidth: Float = 0f,
            val dialFill: Int = Color.TRANSPARENT,
            val isGlassEffect: Boolean = false
        )

        data class WidgetSizeInfo(
            val width: Int,
            val height: Int,
            val isCompact: Boolean
        )

        val themes = listOf(
            ColorTheme(Color.WHITE, Color.WHITE, Color.WHITE, Color.rgb(230, 230, 230), Color.WHITE, Color.rgb(255, 87, 34), Color.rgb(255, 87, 34)),
            ColorTheme(Color.rgb(220, 180, 70), Color.rgb(245, 220, 140), Color.rgb(255, 225, 150), Color.rgb(235, 200, 110), Color.rgb(240, 200, 80), Color.rgb(245, 130, 32), Color.rgb(245, 130, 32)),
            ColorTheme(Color.rgb(190, 200, 215), Color.rgb(230, 240, 255), Color.rgb(230, 240, 255), Color.rgb(190, 205, 220), Color.rgb(220, 230, 245), Color.rgb(235, 65, 65), Color.rgb(235, 65, 65)),
            ColorTheme(Color.rgb(0, 230, 118), Color.rgb(160, 255, 200), Color.rgb(160, 255, 200), Color.rgb(120, 230, 170), Color.rgb(0, 230, 118), Color.rgb(255, 215, 0), Color.rgb(255, 215, 0)),
            ColorTheme(Color.rgb(0, 200, 255), Color.rgb(180, 235, 255), Color.rgb(180, 235, 255), Color.rgb(140, 210, 245), Color.rgb(0, 200, 255), Color.rgb(255, 110, 110), Color.rgb(255, 110, 110)),
            ColorTheme(Color.rgb(224, 64, 251), Color.rgb(245, 180, 255), Color.rgb(245, 180, 255), Color.rgb(210, 150, 230), Color.rgb(224, 64, 251), Color.rgb(0, 230, 118), Color.rgb(0, 230, 118)),
            ColorTheme(Color.rgb(255, 82, 82), Color.rgb(255, 205, 210), Color.rgb(255, 205, 210), Color.rgb(240, 160, 165), Color.rgb(255, 82, 82), Color.rgb(255, 215, 0), Color.rgb(255, 215, 0)),
            ColorTheme(Color.rgb(255, 235, 59), Color.rgb(255, 245, 157), Color.rgb(255, 245, 157), Color.rgb(230, 220, 130), Color.rgb(255, 235, 59), Color.rgb(0, 229, 255), Color.rgb(0, 229, 255)),
            ColorTheme(Color.rgb(24, 255, 255), Color.rgb(178, 255, 247), Color.rgb(178, 255, 247), Color.rgb(130, 230, 220), Color.rgb(24, 255, 255), Color.rgb(255, 64, 129), Color.rgb(255, 64, 129)),
            ColorTheme(Color.rgb(255, 152, 0), Color.rgb(255, 224, 178), Color.rgb(255, 224, 178), Color.rgb(230, 180, 140), Color.rgb(255, 152, 0), Color.rgb(0, 230, 118), Color.rgb(0, 230, 118)),
            ColorTheme(Color.rgb(220, 220, 220), Color.WHITE, Color.WHITE, Color.rgb(190, 190, 190), Color.WHITE, Color.rgb(255, 65, 65), Color.rgb(255, 65, 65), widgetBackground = Color.BLACK, widgetBorder = Color.rgb(120, 120, 120), widgetBorderWidth = 3f, dialFill = Color.rgb(15, 15, 15)),
            ColorTheme(Color.rgb(0, 255, 145), Color.rgb(80, 190, 255), Color.rgb(145, 225, 255), Color.rgb(175, 235, 255), Color.rgb(95, 205, 255), Color.rgb(255, 220, 0), Color.rgb(255, 220, 0), widgetBackground = Color.rgb(20, 32, 28), widgetBorder = Color.rgb(0, 255, 145), widgetBorderWidth = 3.5f, dialFill = Color.rgb(15, 38, 30)),
            ColorTheme(Color.rgb(70, 180, 255), Color.WHITE, Color.rgb(190, 235, 255), Color.rgb(160, 215, 255), Color.WHITE, Color.rgb(255, 215, 0), Color.rgb(255, 215, 0), widgetBackground = Color.rgb(5, 30, 65), widgetBorder = Color.rgb(70, 180, 255), widgetBorderWidth = 3.5f, dialFill = Color.rgb(8, 40, 85)),
            ColorTheme(Color.rgb(255, 80, 80), Color.rgb(255, 225, 225), Color.rgb(255, 205, 205), Color.rgb(245, 170, 170), Color.WHITE, Color.rgb(255, 220, 0), Color.rgb(255, 220, 0), widgetBackground = Color.rgb(55, 8, 8), widgetBorder = Color.rgb(255, 80, 80), widgetBorderWidth = 3.5f, dialFill = Color.rgb(75, 10, 10)),
            ColorTheme(Color.rgb(210, 100, 255), Color.rgb(245, 220, 255), Color.rgb(235, 200, 255), Color.rgb(205, 165, 235), Color.WHITE, Color.rgb(255, 220, 0), Color.rgb(255, 220, 0), widgetBackground = Color.rgb(30, 8, 48), widgetBorder = Color.rgb(210, 100, 255), widgetBorderWidth = 3.5f, dialFill = Color.rgb(45, 10, 70)),
            ColorTheme(Color.rgb(255, 155, 35), Color.rgb(255, 240, 210), Color.rgb(255, 225, 175), Color.rgb(240, 190, 130), Color.WHITE, Color.rgb(70, 230, 130), Color.rgb(70, 230, 130), widgetBackground = Color.rgb(50, 20, 5), widgetBorder = Color.rgb(255, 155, 35), widgetBorderWidth = 3.5f, dialFill = Color.rgb(70, 28, 7)),
            ColorTheme(Color.WHITE, Color.WHITE, Color.WHITE, Color.rgb(220, 220, 220), Color.WHITE, Color.rgb(255, 87, 34), Color.rgb(255, 87, 34), widgetBackground = Color.argb(160, 0, 0, 0), widgetBorder = Color.argb(120, 255, 255, 255), widgetBorderWidth = 2f, dialFill = Color.argb(100, 20, 20, 20)),
            ColorTheme(Color.rgb(100, 200, 255), Color.WHITE, Color.rgb(210, 240, 255), Color.rgb(170, 225, 255), Color.WHITE, Color.rgb(255, 215, 0), Color.rgb(255, 215, 0), widgetBackground = Color.argb(150, 10, 30, 60), widgetBorder = Color.argb(180, 70, 180, 255), widgetBorderWidth = 2.5f, dialFill = Color.argb(100, 15, 45, 85)),
            ColorTheme(Color.rgb(80, 255, 160), Color.rgb(230, 255, 240), Color.rgb(190, 255, 220), Color.rgb(150, 240, 190), Color.WHITE, Color.rgb(255, 215, 0), Color.rgb(255, 215, 0), widgetBackground = Color.argb(150, 10, 50, 30), widgetBorder = Color.argb(180, 80, 255, 160), widgetBorderWidth = 2.5f, dialFill = Color.argb(100, 15, 70, 40)),
            ColorTheme(Color.WHITE, Color.WHITE, Color.WHITE, Color.rgb(230, 240, 255), Color.WHITE, Color.rgb(255, 80, 80), Color.rgb(255, 80, 80), widgetBackground = Color.argb(70, 255, 255, 255), widgetBorder = Color.argb(160, 255, 255, 255), widgetBorderWidth = 2.5f, dialFill = Color.argb(40, 255, 255, 255), isGlassEffect = true),
            ColorTheme(Color.rgb(220, 230, 245), Color.WHITE, Color.WHITE, Color.rgb(200, 215, 235), Color.WHITE, Color.rgb(0, 230, 118), Color.rgb(0, 230, 118), widgetBackground = Color.argb(120, 20, 25, 35), widgetBorder = Color.argb(140, 255, 255, 255), widgetBorderWidth = 2.5f, dialFill = Color.argb(60, 30, 40, 55), isGlassEffect = true),
            ColorTheme(Color.rgb(0, 229, 255), Color.rgb(220, 250, 255), Color.rgb(180, 245, 255), Color.rgb(140, 220, 245), Color.WHITE, Color.rgb(255, 215, 0), Color.rgb(255, 215, 0), widgetBackground = Color.argb(100, 10, 40, 70), widgetBorder = Color.argb(180, 0, 229, 255), widgetBorderWidth = 3f, dialFill = Color.argb(50, 0, 150, 220), isGlassEffect = true),
            ColorTheme(Color.rgb(0, 230, 118), Color.WHITE, Color.rgb(0, 230, 118), Color.rgb(160, 255, 200), Color.WHITE, Color.rgb(0, 230, 118), Color.rgb(0, 230, 118), widgetBackground = Color.rgb(10, 25, 18), widgetBorder = Color.rgb(0, 230, 118), widgetBorderWidth = 3f, dialFill = Color.rgb(15, 35, 25)),
            ColorTheme(Color.rgb(0, 229, 255), Color.WHITE, Color.rgb(0, 229, 255), Color.rgb(180, 245, 255), Color.WHITE, Color.rgb(255, 215, 0), Color.rgb(255, 215, 0), widgetBackground = Color.rgb(12, 28, 42), widgetBorder = Color.rgb(0, 229, 255), widgetBorderWidth = 3f, dialFill = Color.rgb(18, 38, 55)),
            ColorTheme(Color.rgb(212, 175, 55), Color.rgb(255, 215, 0), Color.rgb(255, 223, 0), Color.rgb(238, 201, 0), Color.rgb(212, 175, 55), Color.rgb(255, 87, 34), Color.rgb(255, 87, 34)),
            ColorTheme(Color.rgb(255, 215, 0), Color.rgb(255, 223, 0), Color.rgb(255, 235, 120), Color.rgb(212, 175, 55), Color.rgb(255, 215, 0), Color.rgb(255, 65, 65), Color.rgb(255, 65, 65), widgetBackground = Color.rgb(20, 18, 12), widgetBorder = Color.rgb(212, 175, 55), widgetBorderWidth = 3.5f, dialFill = Color.rgb(30, 26, 15)),
            ColorTheme(Color.rgb(255, 215, 0), Color.rgb(255, 235, 150), Color.rgb(255, 223, 0), Color.rgb(230, 195, 80), Color.rgb(255, 215, 0), Color.rgb(255, 87, 34), Color.rgb(255, 87, 34), widgetBackground = Color.argb(110, 45, 38, 15), widgetBorder = Color.argb(180, 212, 175, 55), widgetBorderWidth = 2.8f, dialFill = Color.argb(50, 60, 50, 20), isGlassEffect = true)
        )

        private fun getThemeIndex(context: Context, appWidgetId: Int): Int {
            val prefs = context.getSharedPreferences("adlam_clock", Context.MODE_PRIVATE)
            return prefs.getInt("theme_index_$appWidgetId", 0).coerceIn(0, themes.lastIndex)
        }

        fun cycleThemeIndex(context: Context, appWidgetId: Int): Int {
            if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) return 0
            val prefs = context.getSharedPreferences("adlam_clock", Context.MODE_PRIVATE)
            val next = (getThemeIndex(context, appWidgetId) + 1) % themes.size
            prefs.edit().putInt("theme_index_$appWidgetId", next).apply()
            return next
        }

        private fun getWidgetSize(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ): WidgetSizeInfo {
            val options = appWidgetManager.getAppWidgetOptions(appWidgetId)
            val widthDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 100)
            val heightDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 100)
            val density = context.resources.displayMetrics.density

            val isCompact = widthDp <= 110 || heightDp <= 110
            val width = max(180, (widthDp * density).roundToInt())
            val height = max(180, (heightDp * density).roundToInt())

            return WidgetSizeInfo(width, height, isCompact)
        }

        private fun createThemePendingIntent(context: Context, appWidgetId: Int): PendingIntent {
            val intent = Intent(context, ClockService::class.java).apply {
                action = ACTION_CYCLE_THEME
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
            }

            return PendingIntent.getService(
                context,
                appWidgetId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        fun updateWidgetDirectly(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            try {
                val sizeInfo = getWidgetSize(context, appWidgetManager, appWidgetId)
                val bitmap = Bitmap.createBitmap(sizeInfo.width, sizeInfo.height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)

                drawClock(context, canvas, sizeInfo.width, sizeInfo.height, appWidgetId, sizeInfo.isCompact)

                val views = RemoteViews(context.packageName, R.layout.adlam_clock_widget)
                views.setImageViewBitmap(R.id.clock_image_view, bitmap)
                views.setOnClickPendingIntent(
                    R.id.clock_image_view,
                    createThemePendingIntent(context, appWidgetId)
                )

                appWidgetManager.updateAppWidget(appWidgetId, views)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun updateDigitalWidgetDirectly(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            try {
                val sizeInfo = getWidgetSize(context, appWidgetManager, appWidgetId)
                val bitmap = Bitmap.createBitmap(sizeInfo.width, sizeInfo.height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)

                drawDigitalClock(context, canvas, sizeInfo.width, sizeInfo.height, appWidgetId, sizeInfo.isCompact)

                val views = RemoteViews(context.packageName, R.layout.adlam_digital_clock_widget)
                views.setImageViewBitmap(R.id.digital_clock_image_view, bitmap)
                views.setOnClickPendingIntent(
                    R.id.digital_clock_image_view,
                    createThemePendingIntent(context, appWidgetId)
                )

                appWidgetManager.updateAppWidget(appWidgetId, views)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)

            val analogComponent = ComponentName(context, AdlamClockWidget::class.java)
            for (id in manager.getAppWidgetIds(analogComponent)) {
                updateWidgetDirectly(context, manager, id)
            }

            val digitalComponent = ComponentName(context, AdlamDigitalClockWidget::class.java)
            for (id in manager.getAppWidgetIds(digitalComponent)) {
                updateDigitalWidgetDirectly(context, manager, id)
            }

            AdlamCalendarWidget.updateAll(context)
        }

        private fun drawClock(
            context: Context,
            canvas: Canvas,
            width: Int,
            height: Int,
            appWidgetId: Int,
            isCompact: Boolean = false
        ) {
            val theme = themes[getThemeIndex(context, appWidgetId)]
            val w = width.toFloat()
            val h = height.toFloat()
            val smallest = min(w, h)
            val cx = w / 2f
            val cy = h / 2f
            val radius = smallest * 0.44f

            if (theme.widgetBackground != Color.TRANSPARENT) {
                val margin = smallest * 0.015f
                val rect = RectF(margin, margin, w - margin, h - margin)

                val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.FILL
                    color = theme.widgetBackground
                }
                canvas.drawRoundRect(rect, smallest * 0.12f, smallest * 0.12f, bgPaint)

                if (theme.isGlassEffect) {
                    val glassHighlight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        shader = LinearGradient(
                            margin, margin, w - margin, h * 0.4f,
                            intArrayOf(
                                Color.argb(90, 255, 255, 255),
                                Color.argb(20, 255, 255, 255),
                                Color.TRANSPARENT
                            ),
                            null,
                            Shader.TileMode.CLAMP
                        )
                    }
                    canvas.drawRoundRect(rect, smallest * 0.12f, smallest * 0.12f, glassHighlight)
                }

                if (theme.widgetBorder != Color.TRANSPARENT && theme.widgetBorderWidth > 0f) {
                    val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        style = Paint.Style.STROKE
                        color = theme.widgetBorder
                        strokeWidth = theme.widgetBorderWidth * smallest / 420f
                    }
                    canvas.drawRoundRect(rect, smallest * 0.12f, smallest * 0.12f, borderPaint)
                }
            }

            if (theme.dialFill != Color.TRANSPARENT) {
                val dialPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.FILL
                    color = theme.dialFill
                }
                canvas.drawCircle(cx, cy, radius, dialPaint)
            }

            if (theme.dialBorder != Color.TRANSPARENT) {
                val dialBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    color = theme.dialBorder
                    strokeWidth = smallest * 0.006f
                }
                canvas.drawCircle(cx, cy, radius, dialBorderPaint)
            }

            val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = theme.ticks
                strokeCap = Paint.Cap.ROUND
            }

            for (i in 0 until 60) {
                val angle = Math.toRadians((i * 6.0) - 90.0)
                val isHour = i % 5 == 0

                val innerR = if (isHour) radius * 0.88f else radius * 0.93f
                val outerR = radius * 0.97f

                tickPaint.strokeWidth = if (isHour) smallest * 0.008f else smallest * 0.003f

                val startX = cx + cos(angle).toFloat() * innerR
                val startY = cy + sin(angle).toFloat() * innerR
                val stopX = cx + cos(angle).toFloat() * outerR
                val stopY = cy + sin(angle).toFloat() * outerR

                canvas.drawLine(startX, startY, stopX, stopY, tickPaint)
            }

            val font = FontLoader.getTypeface(context)
            val numberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textAlign = Paint.Align.CENTER
                color = theme.numbersText
                typeface = font ?: Typeface.DEFAULT_BOLD
                textSize = smallest * 0.088f
            }

            val numbers = arrayOf("12", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11")
            for (i in 0 until 12) {
                val angle = Math.toRadians((i * 30.0) - 90.0)
                val x = cx + cos(angle).toFloat() * radius * 0.74f
                val y = cy + sin(angle).toFloat() * radius * 0.74f - (numberPaint.ascent() + numberPaint.descent()) / 2f
                canvas.drawText(toAdlam(numbers[i]), x, y, numberPaint)
            }

            val calendar = Calendar.getInstance(TimeZone.getDefault())
            val hour24 = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)
            val second = calendar.get(Calendar.SECOND)

            if (!isCompact) {
                val digitalTimeStr = "${twoDigits(hour24)}:${twoDigits(minute)}"
                val digitalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    textAlign = Paint.Align.CENTER
                    color = theme.digitalTimeText
                    typeface = font ?: Typeface.MONOSPACE
                    textSize = smallest * 0.055f
                }
                canvas.drawText(toAdlam(digitalTimeStr), cx, cy - radius * 0.42f, digitalPaint)

                val weekday = getWeekdayAdlam(calendar.get(Calendar.DAY_OF_WEEK))
                val weekdayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    textAlign = Paint.Align.CENTER
                    color = theme.infoText
                    textSize = smallest * 0.048f
                    typeface = font ?: Typeface.DEFAULT_BOLD
                }
                canvas.drawText(weekday, cx, cy + radius * 0.38f, weekdayPaint)

                val day = calendar.get(Calendar.DAY_OF_MONTH)
                val month = calendar.get(Calendar.MONTH)
                val year = calendar.get(Calendar.YEAR)
                val dateText = "${toAdlam(day.toString())} ${getMonthAdlam(month)} ${toAdlam(year.toString())}"

                val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    textAlign = Paint.Align.CENTER
                    color = theme.infoText
                    textSize = smallest * 0.044f
                    typeface = font ?: Typeface.DEFAULT_BOLD
                }
                canvas.drawText(dateText, cx, cy + radius * 0.54f, datePaint)
            }

            val hour = hour24 % 12
            val hourAngle = (hour * 30f) + (minute * 0.5f)
            val minuteAngle = minute * 6f + second * 0.1f
            val secondAngle = second * 6f

            drawHand(canvas, cx, cy, radius * 0.48f, hourAngle, smallest * 0.022f, theme.hourMinHand)
            drawHand(canvas, cx, cy, radius * 0.70f, minuteAngle, smallest * 0.015f, theme.hourMinHand)
            drawSecondHand(canvas, cx, cy, radius * 0.82f, secondAngle, smallest * 0.005f, theme.secondHand)

            val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = theme.centerCap
            }
            canvas.drawCircle(cx, cy, smallest * 0.022f, centerPaint)
        }

        private fun drawHand(
            canvas: Canvas,
            cx: Float,
            cy: Float,
            length: Float,
            angle: Float,
            strokeWidth: Float,
            color: Int
        ) {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                this.strokeWidth = strokeWidth
                this.color = color
            }
            val radians = Math.toRadians((angle - 90f).toDouble())
            val x = cx + cos(radians).toFloat() * length
            val y = cy + sin(radians).toFloat() * length
            canvas.drawLine(cx, cy, x, y, paint)
        }

        private fun drawSecondHand(
            canvas: Canvas,
            cx: Float,
            cy: Float,
            length: Float,
            angle: Float,
            strokeWidth: Float,
            color: Int
        ) {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                this.strokeWidth = strokeWidth
                this.color = color
            }
            val radians = Math.toRadians((angle - 90f).toDouble())
            val x = cx + cos(radians).toFloat() * length
            val y = cy + sin(radians).toFloat() * length
            val backX = cx - cos(radians).toFloat() * (length * 0.22f)
            val backY = cy - sin(radians).toFloat() * (length * 0.22f)
            canvas.drawLine(backX, backY, x, y, paint)
        }

        private fun drawDigitalClock(
            context: Context,
            canvas: Canvas,
            width: Int,
            height: Int,
            appWidgetId: Int,
            isCompact: Boolean = false
        ) {
            val theme = themes[getThemeIndex(context, appWidgetId)]
            val w = width.toFloat()
            val h = height.toFloat()
            val smallest = min(w, h)

            if (theme.widgetBackground != Color.TRANSPARENT) {
                val margin = smallest * 0.015f
                val rect = RectF(margin, margin, w - margin, h - margin)

                val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.FILL
                    color = theme.widgetBackground
                }
                canvas.drawRoundRect(rect, smallest * 0.08f, smallest * 0.08f, bgPaint)

                if (theme.isGlassEffect) {
                    val glassHighlight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        shader = LinearGradient(
                            margin, margin, w - margin, h * 0.45f,
                            intArrayOf(
                                Color.argb(80, 255, 255, 255),
                                Color.argb(15, 255, 255, 255),
                                Color.TRANSPARENT
                            ),
                            null,
                            Shader.TileMode.CLAMP
                        )
                    }
                    canvas.drawRoundRect(rect, smallest * 0.08f, smallest * 0.08f, glassHighlight)
                }

                if (theme.widgetBorder != Color.TRANSPARENT && theme.widgetBorderWidth > 0f) {
                    val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        style = Paint.Style.STROKE
                        color = theme.widgetBorder
                        strokeWidth = theme.widgetBorderWidth * smallest / 420f
                    }
                    canvas.drawRoundRect(rect, smallest * 0.08f, smallest * 0.08f, borderPaint)
                }
            }

            val calendar = Calendar.getInstance(TimeZone.getDefault())
            val hour = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)
            val font = FontLoader.getTypeface(context)
            val timeText = toAdlam("${twoDigits(hour)}:${twoDigits(minute)}")

            if (isCompact) {
                val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    textAlign = Paint.Align.CENTER
                    color = theme.digitalTimeText
                    typeface = font ?: Typeface.DEFAULT_BOLD
                    textSize = smallest * 0.45f
                    textScaleX = 0.65f
                }

                canvas.save()
                val timeCenterY = h * 0.5f
                canvas.scale(1.0f, 1.3f, w / 2f, timeCenterY)
                canvas.drawText(
                    timeText,
                    w / 2f,
                    timeCenterY - (timePaint.ascent() + timePaint.descent()) / 2f,
                    timePaint
                )
                canvas.restore()
            } else {
                val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    textAlign = Paint.Align.CENTER
                    color = theme.digitalTimeText
                    typeface = font ?: Typeface.DEFAULT
                    textSize = smallest * 0.38f
                    textScaleX = 0.55f
                }

                canvas.save()
                val timeCenterY = h * 0.42f
                canvas.scale(1.0f, 1.45f, w / 2f, timeCenterY)
                canvas.drawText(
                    timeText,
                    w / 2f,
                    timeCenterY - (timePaint.ascent() + timePaint.descent()) / 2f,
                    timePaint
                )
                canvas.restore()

                val hasThemeBackground = theme.widgetBackground != Color.TRANSPARENT || theme.dialFill != Color.TRANSPARENT

                if (hasThemeBackground) {
                    val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = theme.infoText
                        strokeWidth = smallest * 0.004f
                    }
                    canvas.drawLine(w * 0.25f, h * 0.68f, w * 0.75f, h * 0.68f, linePaint)
                }

                val day = calendar.get(Calendar.DAY_OF_MONTH)
                val month = calendar.get(Calendar.MONTH)
                val year = calendar.get(Calendar.YEAR)
                val dateText = "${toAdlam(day.toString())} ${getMonthAdlam(month)} ${toAdlam(year.toString())}"

                val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    textAlign = Paint.Align.CENTER
                    color = theme.infoText
                    textSize = smallest * 0.052f
                    typeface = font ?: Typeface.DEFAULT_BOLD
                }

                val dateY = if (hasThemeBackground) h * 0.78f else h * 0.68f
                canvas.drawText(dateText, w / 2f, dateY, datePaint)
            }
        }

        private fun getWeekdayAdlam(day: Int): String {
            return when (day) {
                Calendar.SUNDAY -> "𞤁𞤫𞤱𞤮"
                Calendar.MONDAY -> "𞤀𞥄𞤩𞤲𞤣𞤫"
                Calendar.TUESDAY -> "𞤃𞤢𞤱𞤦𞤢𞥄𞤪𞤫"
                Calendar.WEDNESDAY -> "𞤐𞤶𞤫𞤧𞤤𞤢𞥄𞤪𞤫"
                Calendar.THURSDAY -> "𞤐𞤢𞥄𞤧𞤢𞥄𞤲𞤣𞤫"
                Calendar.FRIDAY -> "𞤃𞤢𞤱𞤲'𞤣𞤫"
                Calendar.SATURDAY -> "𞤖𞤮𞤪𞤦𞤭𞤪𞥆𞤫"
                else -> ""
            }
        }

        private fun getMonthAdlam(month: Int): String {
            return when (month) {
                Calendar.JANUARY -> "𞤅𞤭𞥅𞤤𞤮"
                Calendar.FEBRUARY -> "𞤕𞤮𞤤𞤼𞤮"
                Calendar.MARCH -> "𞤐𞤄𞤮𞥅𞤴𞤮"
                Calendar.APRIL -> "𞤅𞤫𞤯𞤼𞤮"
                Calendar.MAY -> "𞤁𞤵𞥅𞤶𞤮"
                Calendar.JUNE -> "𞤑𞤮𞤪𞤧𞤮"
                Calendar.JULY -> "𞤃𞤮𞤪𞤧𞤮"
                Calendar.AUGUST -> "𞤔𞤵𞤳𞤮"
                Calendar.SEPTEMBER -> "𞤅𞤭𞤤𞤼𞤮"
                Calendar.OCTOBER -> "𞤒𞤢𞤪𞤳𞤮"
                Calendar.NOVEMBER -> "𞤔𞤮𞤤𞤮"
                Calendar.DECEMBER -> "𞤄𞤮𞤱𞤼𞤮"
                else -> ""
            }
        }

        private fun toAdlam(value: String): String {
            return value
                .replace("0", "𞥐")
                .replace("1", "𞥑")
                .replace("2", "𞥒")
                .replace("3", "𞥓")
                .replace("4", "𞥔")
                .replace("5", "𞥕")
                .replace("6", "𞥖")
                .replace("7", "𞥗")
                .replace("8", "𞥘")
                .replace("9", "𞥙")
        }

        private fun twoDigits(value: Int): String {
            return if (value < 10) "0$value" else value.toString()
        }

        private fun createNotification(context: Context): Notification {
            val intent = Intent(context, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            return NotificationCompat.Builder(context, CHANNEL_ID)
                .setContentTitle("𞤀𞤺𞤮𞥅𞤺𞤮")
                .setContentText("𞤅𞤢𞤱𞤢 𞤃𞤢𞤤𞤢")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setSilent(true)
                .build()
        }

        private fun createNotificationChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Adlam Clock",
                    NotificationManager.IMPORTANCE_LOW
                )
                channel.description = "خدمة ساعة Fulfulde Adlam"
                channel.setSound(null, null)

                val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                manager.createNotificationChannel(channel)
            }
        }
    }
}
