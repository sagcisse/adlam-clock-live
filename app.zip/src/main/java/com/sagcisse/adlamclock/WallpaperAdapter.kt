package com.sagcisse.adlamclock

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class WallpaperAdapter(
    private val items: List<Int>,
    private var selectedResId: Int
) : RecyclerView.Adapter<WallpaperAdapter.WallpaperViewHolder>() {

    inner class WallpaperViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imgWallpaper: ImageView = view.findViewById(R.id.imgWallpaper)
        val selectionOverlay: View = view.findViewById(R.id.selectionOverlay)
        val txtSelectedBadge: TextView = view.findViewById(R.id.txtSelectedBadge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WallpaperViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_wallpaper, parent, false)
        return WallpaperViewHolder(view)
    }

    override fun onBindViewHolder(holder: WallpaperViewHolder, position: Int) {
        val resId = items[position]

        if (resId == 0 || resId == -1) {
            holder.imgWallpaper.setImageResource(android.R.color.black)
        } else {
            holder.imgWallpaper.setImageResource(resId)
        }

        val isSelected = (resId == selectedResId)
        holder.selectionOverlay.visibility = if (isSelected) View.VISIBLE else View.GONE
        holder.txtSelectedBadge.visibility = if (isSelected) View.VISIBLE else View.GONE

        holder.itemView.setOnClickListener { context ->
            val intent = Intent(holder.itemView.context, WallpaperPreviewActivity::class.java).apply {
                putExtra("selected_res_id", resId)
            }
            holder.itemView.context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int = items.size
}
