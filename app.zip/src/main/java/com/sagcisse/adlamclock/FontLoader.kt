package com.sagcisse.adlamclock

import android.content.Context
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import androidx.core.content.res.ResourcesCompat
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

object FontLoader {

    private const val FONT_URL = "https://raw.githubusercontent.com/google/fonts/main/ofl/adlamdisplay/ADLaMDisplay-Regular.ttf"
    private const val CACHED_FONT_NAME = "adlam_display_downloaded.ttf"

    private var cachedTypeface: Typeface? = null

    @Volatile
    private var isDownloading = false

    /**
     * جلب خط ADLaM Display للتطبيق
     */
    fun getTypeface(context: Context): Typeface {
        // 1. إرجاع الخط مباشرة إذا كان محملاً في الذاكرة
        cachedTypeface?.let { return it }

        // 2. محاولة تحميل خط adlam_display من مجلد الموارد المحلي res/font/adlam_display.ttf
        try {
            val localTypeface = ResourcesCompat.getFont(context, R.font.adlam_display)
            if (localTypeface != null) {
                cachedTypeface = localTypeface
                return localTypeface
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 3. قراءة خط ADLaM Display المحفوظ سابقاً في كاش الجهاز
        try {
            val fontFile = File(context.cacheDir, CACHED_FONT_NAME)
            if (fontFile.exists() && fontFile.length() > 0) {
                val downloadedTypeface = Typeface.createFromFile(fontFile)
                if (downloadedTypeface != null) {
                    cachedTypeface = downloadedTypeface
                    return downloadedTypeface
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 4. تحميل الخط أونلاين من Google Fonts في حال عدم وجوده
        loadFromInternet(context, null)

        return Typeface.DEFAULT_BOLD
    }

    /**
     * تنزيل خط ADLaM Display من الإنترنت في الخلفية
     */
    fun loadFromInternet(context: Context, onLoaded: (() -> Unit)?) {
        if (isDownloading) return
        isDownloading = true

        Thread {
            try {
                val fontFile = File(context.cacheDir, CACHED_FONT_NAME)
                if (!fontFile.exists() || fontFile.length() == 0L) {
                    val url = URL(FONT_URL)
                    val connection = url.openConnection() as HttpURLConnection
                    connection.connectTimeout = 10000
                    connection.readTimeout = 10000
                    connection.connect()

                    if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                        connection.inputStream.use { input ->
                            FileOutputStream(fontFile).use { output ->
                                input.copyTo(output)
                            }
                        }
                    }
                }

                if (fontFile.exists() && fontFile.length() > 0L) {
                    val downloadedTypeface = Typeface.createFromFile(fontFile)
                    cachedTypeface = downloadedTypeface

                    Handler(Looper.getMainLooper()).post {
                        onLoaded?.invoke()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isDownloading = false
            }
        }.start()
    }
}
