package com.sagcisse.adlamclock

import android.app.AlertDialog
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import java.util.Calendar
import kotlin.math.abs

class FulfuldeCalendar @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var customTheme: AdlamCalendarWidget.Companion.ColorTheme? = null

    fun setTheme(theme: AdlamCalendarWidget.Companion.ColorTheme) {
        customTheme = theme
        invalidate()
    }

    private val calendar: Calendar = Calendar.getInstance()
    private val todayCalendar: Calendar = Calendar.getInstance()

    private var currentMonth: Int = calendar.get(Calendar.MONTH)
    private var currentYear: Int = calendar.get(Calendar.YEAR)

    private var isYearlyView = false

    private val monthRects = Array(12) { RectF() }

    private var touchStartX = 0f
    private var touchStartY = 0f
    private var touchDownTime = 0L

    private val swipeThreshold = 100f
    private val swipeVerticalLimit = 180f

    // ============================================================
    // أسماء الشهور
    // ============================================================

    private val months = arrayOf(
        "𞤅𞤭𞥅𞤤𞤮",
        "𞤕𞤮𞤤𞤼𞤮",
        "𞤐𞤄𞤮𞥅𞤴𞤮",
        "𞤅𞤫𞤯𞤼𞤮",
        "𞤁𞤵𞥅𞤶𞤮",
        "𞤑𞤮𞤪𞤧𞤮",
        "𞤃𞤮𞤪𞤧𞤮",
        "𞤔𞤵𞤳𞤮",
        "𞤅𞤭𤤤𞤼𞤮",
        "𞤒𞤢𞤪𞤳𞤮",
        "𞤔𞤮𞤤𞤮",
        "𞤄𞤮𞤱𞤼𞤮"
    )

    // ============================================================
    // أيام الأسبوع (من اليمين إلى اليسار)
    // ============================================================

    private val daysOfWeekRtl = arrayOf(
        "𞤖𞤮",
        "𞤃𞤢𞤱",
        "𞤐𞤢𞥄",
        "𞤐𞤶",
        "𞤃𞤢𞤱",
        "𞤀𞥄𞤩",
        "𞤁𞤫"
    )

    private val headerRect = RectF()
    private val prevMonthRect = RectF()
    private val nextMonthRect = RectF()
    private val monthClickRect = RectF()
    private val yearClickRect = RectF()

    // ============================================================
    // تحويل الأرقام إلى أرقام Adlam
    // ============================================================

    private fun toAdlamDigits(number: Int): String {
        return number.toString().map { ch ->
            when (ch) {
                '0' -> "𞥐"
                '1' -> "𞥑"
                '2' -> "𞥒"
                '3' -> "𞥓"
                '4' -> "𞥔"
                '5' -> "𞥕"
                '6' -> "𞥖"
                '7' -> "𞥗"
                '8' -> "𞥘"
                '9' -> "𞥙"
                else -> ch.toString()
            }
        }.joinToString("")
    }

    // ============================================================
    // الرسم الرئيسي
    // ============================================================

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val width = width.toFloat()
        val height = height.toFloat()
        if (width <= 0f || height <= 0f) return

        val smallest = minOf(width, height)
        val margin = smallest * 0.015f
        val bgRect = RectF(margin, margin, width - margin, height - margin)
        val cornerRadius = smallest * 0.08f

        val customFont = FontLoader.getTypeface(context) ?: Typeface.DEFAULT

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = customFont
            style = Paint.Style.FILL
        }

        val theme = customTheme

        // ========================================================
        // خلفية التقويم (مطابقة لـ ClockService)
        // ========================================================

        if (theme != null) {
            if (theme.widgetBackground != Color.TRANSPARENT) {
                paint.style = Paint.Style.FILL
                paint.color = theme.widgetBackground
                canvas.drawRoundRect(bgRect, cornerRadius, cornerRadius, paint)

                // رسم التأثير الزجاجي (Glassmorphism)
                if (theme.isGlassEffect) {
                    val glassHighlight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        shader = LinearGradient(
                            margin, margin, width - margin, height * 0.45f,
                            intArrayOf(
                                Color.argb(80, 255, 255, 255),
                                Color.argb(15, 255, 255, 255),
                                Color.TRANSPARENT
                            ),
                            null,
                            Shader.TileMode.CLAMP
                        )
                    }
                    canvas.drawRoundRect(bgRect, cornerRadius, cornerRadius, glassHighlight)
                }

                // رسم الإطار الخارجي المضيء
                if (theme.widgetBorder != Color.TRANSPARENT && theme.widgetBorderWidth > 0f) {
                    val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        style = Paint.Style.STROKE
                        color = theme.widgetBorder
                        strokeWidth = theme.widgetBorderWidth * smallest / 420f
                    }
                    canvas.drawRoundRect(bgRect, cornerRadius, cornerRadius, borderPaint)
                }
            } else if (theme.dialFill != Color.TRANSPARENT) {
                paint.style = Paint.Style.FILL
                paint.color = theme.dialFill
                canvas.drawRoundRect(bgRect, cornerRadius, cornerRadius, paint)
            }
        } else {
            // خلفية فصول السنة الافتراضية في حال عدم اختيار ثيم
            val seasonColors = when (currentMonth) {
                2, 3, 4 -> intArrayOf(Color.parseColor("#122415"), Color.parseColor("#080D09"))
                5, 6, 7 -> intArrayOf(Color.parseColor("#2B180A"), Color.parseColor("#0F0803"))
                8, 9, 10 -> intArrayOf(Color.parseColor("#24150A"), Color.parseColor("#0D0703"))
                else -> intArrayOf(Color.parseColor("#0F1A2B"), Color.parseColor("#060A12"))
            }
            paint.shader = LinearGradient(0f, 0f, 0f, height, seasonColors, null, Shader.TileMode.CLAMP)
            canvas.drawRoundRect(bgRect, cornerRadius, cornerRadius, paint)
            paint.shader = null
        }

        val headerHeight = height * 0.08f

        headerRect.set(0f, 0f, width, headerHeight)

        // ========================================================
        // عرض السنة الكاملة
        // ========================================================

        if (isYearlyView) {
            drawYearlyView(canvas, width, height, headerHeight, paint)
            return
        }

        // ========================================================
        // أزرار الشهر السابق / التالي
        // ========================================================

        val btnSize = headerHeight * 0.45f

        prevMonthRect.set(
            24f,
            (headerHeight - btnSize) / 2f,
            24f + btnSize,
            (headerHeight + btnSize) / 2f
        )

        nextMonthRect.set(
            width - 24f - btnSize,
            (headerHeight - btnSize) / 2f,
            width - 24f,
            (headerHeight + btnSize) / 2f
        )

        paint.style = Paint.Style.FILL
        paint.color = theme?.hourMinHand ?: Color.parseColor("#E0A96D")

        canvas.drawRoundRect(prevMonthRect, 12f, 12f, paint)
        canvas.drawRoundRect(nextMonthRect, 12f, 12f, paint)

        // ========================================================
        // أسهم التنقل
        // ========================================================

        paint.color = Color.BLACK
        paint.textSize = btnSize * 0.45f
        paint.textAlign = Paint.Align.CENTER

        canvas.drawText(
            "❮",
            prevMonthRect.centerX(),
            prevMonthRect.centerY() - (paint.ascent() + paint.descent()) / 2f,
            paint
        )

        canvas.drawText(
            "❯",
            nextMonthRect.centerX(),
            nextMonthRect.centerY() - (paint.ascent() + paint.descent()) / 2f,
            paint
        )

        // ========================================================
        // عنوان الشهر والسنة
        // ========================================================

        paint.color = theme?.digitalTimeText ?: Color.WHITE
        paint.textSize = headerHeight * 0.38f
        paint.textAlign = Paint.Align.CENTER

        val monthText = months[currentMonth]
        val yearText = "${toAdlamDigits(currentYear)} ▾"
        val headerTitle = "$monthText   $yearText"

        val titleX = width / 2f
        val titleY = headerHeight / 2f - (paint.ascent() + paint.descent()) / 2f

        canvas.drawText(headerTitle, titleX, titleY, paint)

        val titleWidth = paint.measureText(headerTitle)

        monthClickRect.set(titleX - titleWidth / 2f, 0f, titleX, headerHeight)
        yearClickRect.set(titleX, 0f, titleX + titleWidth / 2f, headerHeight)

        // ========================================================
        // رأس أيام الأسبوع
        // ========================================================

        val daysHeaderY = headerHeight + 10f
        val cellWidth = width / 7f
        val daysHeaderHeight = height * 0.055f

        val isCurrentMonthAndYear = currentMonth == todayCalendar.get(Calendar.MONTH) &&
                currentYear == todayCalendar.get(Calendar.YEAR)

        val rawTodayDow = todayCalendar.get(Calendar.DAY_OF_WEEK)
        val todayRtlIndex = if (rawTodayDow == 7) 0 else 7 - rawTodayDow

        paint.textSize = daysHeaderHeight * 0.38f

        for (i in 0 until 7) {

            val cellX = i * cellWidth
            val isTodayHeader = isCurrentMonthAndYear && i == todayRtlIndex

            if (isTodayHeader) {
                paint.color = theme?.secondHand ?: Color.parseColor("#FFD700")

                val highlightRect = RectF(
                    cellX + 6f,
                    daysHeaderY,
                    cellX + cellWidth - 6f,
                    daysHeaderY + daysHeaderHeight
                )

                canvas.drawRoundRect(highlightRect, 10f, 10f, paint)
                paint.color = Color.BLACK
            } else {
                paint.color = theme?.infoText ?: Color.parseColor("#90A4AE")
            }

            val textX = cellX + cellWidth / 2f
            val headerTextY = daysHeaderY + daysHeaderHeight / 2f - (paint.ascent() + paint.descent()) / 2f

            canvas.drawText(daysOfWeekRtl[i], textX, headerTextY, paint)
        }

        // ========================================================
        // شبكة الأيام (تم تصحيح الحسابات والمحاذاة)
        // ========================================================

        val gridStartY = daysHeaderY + daysHeaderHeight + 10f
        val gridHeight = height - gridStartY - 15f

        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, currentYear)
            set(Calendar.MONTH, currentMonth)
            set(Calendar.DAY_OF_MONTH, 1)
        }

        val firstDayStandard = cal.get(Calendar.DAY_OF_WEEK) // 1=الأحد ... 7=السبت
        val emptyCellsBeforeMonth = firstDayStandard - 1
        val maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val rowHeight = gridHeight / 6f

        paint.textSize = rowHeight * 0.30f

        for (dayCounter in 1..maxDays) {
            val offsetIndex = (dayCounter - 1) + emptyCellsBeforeMonth
            val row = offsetIndex / 7
            val stdCol = offsetIndex % 7
            val displayCol = 6 - stdCol

            val x = displayCol * cellWidth + cellWidth / 2f
            val y = gridStartY + row * rowHeight + rowHeight / 2f

            val isToday = isCurrentMonthAndYear && dayCounter == todayCalendar.get(Calendar.DAY_OF_MONTH)

            if (isToday) {
                paint.color = theme?.secondHand ?: Color.parseColor("#FFD700")

                val radius = minOf(cellWidth, rowHeight) * 0.32f

                canvas.drawRoundRect(
                    x - radius,
                    y - radius,
                    x + radius,
                    y + radius,
                    12f,
                    12f,
                    paint
                )

                paint.color = Color.BLACK
            } else {
                paint.color = theme?.numbersText ?: Color.WHITE
            }

            val dayStr = toAdlamDigits(dayCounter)
            val numY = y - (paint.ascent() + paint.descent()) / 2f

            canvas.drawText(dayStr, x, numY, paint)
        }
    }

    // ============================================================
    // عرض السنة كاملة (12 شهراً)
    // ============================================================

    private fun drawYearlyView(
        canvas: Canvas,
        width: Float,
        height: Float,
        headerH: Float,
        paint: Paint
    ) {

        val theme = customTheme
        val rows = 4
        val cols = 3

        val topMargin = headerH * 0.85f
        val gridH = height - topMargin - 10f
        val cellW = width / cols
        val cellH = gridH / rows

        // السنة في أعلى الصفحة
        paint.color = theme?.digitalTimeText ?: Color.WHITE
        paint.textSize = headerH * 0.45f
        paint.textAlign = Paint.Align.CENTER

        canvas.drawText(
            toAdlamDigits(currentYear),
            width / 2f,
            headerH * 0.45f - (paint.ascent() + paint.descent()) / 2f,
            paint
        )

        val miniCal = Calendar.getInstance()

        for (i in 0 until 12) {

            val row = i / cols
            val col = 2 - (i % cols)

            val left = col * cellW
            val top = topMargin + row * cellH
            val right = left + cellW
            val bottom = top + cellH

            monthRects[i].set(left + 4f, top + 4f, right - 4f, bottom - 4f)

            // خلفية الشهر الفرعي
            paint.color = if (theme?.dialFill != null && theme.dialFill != Color.TRANSPARENT) {
                theme.dialFill
            } else {
                Color.argb(115, 0, 0, 0)
            }
            paint.style = Paint.Style.FILL

            canvas.drawRoundRect(monthRects[i], 10f, 10f, paint)

            // إطار الشهر الفرعي
            paint.color = theme?.hourMinHand ?: theme?.widgetBorder ?: Color.parseColor("#E0A96D")
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = maxOf(1f, cellW * 0.006f)

            canvas.drawRoundRect(monthRects[i], 10f, 10f, paint)
            paint.style = Paint.Style.FILL

            // اسم الشهر
            paint.color = if (i == currentMonth && currentYear == todayCalendar.get(Calendar.YEAR)) {
                theme?.secondHand ?: Color.parseColor("#FFD700")
            } else {
                theme?.infoText ?: Color.parseColor("#E0A96D")
            }

            paint.textSize = cellH * 0.095f
            paint.textAlign = Paint.Align.CENTER

            val titleY = top + cellH * 0.13f
            canvas.drawText(months[i], left + cellW / 2f, titleY, paint)

            // أيام الأسبوع الفرعية
            val dayColW = (cellW - 8f) / 7f
            val dayHeaderY = titleY + cellH * 0.10f

            paint.textSize = cellH * 0.055f
            paint.color = theme?.infoText ?: Color.parseColor("#80FFFFFF")

            for (d in 0 until 7) {
                val dx = left + 4f + d * dayColW + dayColW / 2f
                canvas.drawText(daysOfWeekRtl[d], dx, dayHeaderY, paint)
            }

            // رسم شبكة الأيام لكل شهر
            miniCal.set(Calendar.YEAR, currentYear)
            miniCal.set(Calendar.MONTH, i)
            miniCal.set(Calendar.DAY_OF_MONTH, 1)

            val firstDayStandard = miniCal.get(Calendar.DAY_OF_WEEK)
            val emptyCellsBeforeMonth = firstDayStandard - 1
            val maxDays = miniCal.getActualMaximum(Calendar.DAY_OF_MONTH)

            val gridStartY = dayHeaderY + cellH * 0.04f
            val availableGridH = (bottom - 4f) - gridStartY
            val dayRowH = availableGridH / 6f

            paint.textSize = cellH * 0.052f

            for (dayCounter in 1..maxDays) {
                val offsetIndex = (dayCounter - 1) + emptyCellsBeforeMonth
                val r = offsetIndex / 7
                val stdCol = offsetIndex % 7
                val displayC = 6 - stdCol

                val cx = left + 4f + displayC * dayColW + dayColW / 2f
                val cy = gridStartY + r * dayRowH + dayRowH / 2f

                val isToday = currentYear == todayCalendar.get(Calendar.YEAR) &&
                        i == todayCalendar.get(Calendar.MONTH) &&
                        dayCounter == todayCalendar.get(Calendar.DAY_OF_MONTH)

                if (isToday) {
                    paint.color = theme?.secondHand ?: Color.parseColor("#FFD700")
                    paint.style = Paint.Style.FILL

                    val rRadius = minOf(dayColW, dayRowH) * 0.38f

                    canvas.drawRoundRect(
                        cx - rRadius,
                        cy - rRadius,
                        cx + rRadius,
                        cy + rRadius,
                        4f,
                        4f,
                        paint
                    )

                    paint.color = Color.BLACK
                } else {
                    paint.color = theme?.numbersText ?: Color.WHITE
                }

                val textY = cy - (paint.ascent() + paint.descent()) / 2f
                canvas.drawText(toAdlamDigits(dayCounter), cx, textY, paint)
            }
        }
    }

    // ============================================================
    // اللمس والسحب
    // ============================================================

    override fun onTouchEvent(event: MotionEvent): Boolean {

        when (event.actionMasked) {

            MotionEvent.ACTION_DOWN -> {
                touchStartX = event.x
                touchStartY = event.y
                touchDownTime = System.currentTimeMillis()
                return true
            }

            MotionEvent.ACTION_UP -> {

                val endX = event.x
                val endY = event.y
                val deltaX = endX - touchStartX
                val deltaY = endY - touchStartY

                val isHorizontalSwipe = abs(deltaX) >= swipeThreshold &&
                        abs(deltaY) <= swipeVerticalLimit &&
                        abs(deltaX) > abs(deltaY)

                if (isHorizontalSwipe) {
                    if (deltaX < 0) {
                        if (isYearlyView) currentYear++ else changeMonth(1)
                    } else {
                        if (isYearlyView) currentYear-- else changeMonth(-1)
                    }
                    invalidate()
                    return true
                }

                val x = event.x
                val y = event.y

                if (isYearlyView) {
                    for (i in 0..11) {
                        if (monthRects[i].contains(x, y)) {
                            currentMonth = i
                            isYearlyView = false
                            invalidate()
                            return true
                        }
                    }
                } else {
                    when {
                        prevMonthRect.contains(x, y) -> {
                            changeMonth(-1)
                            return true
                        }

                        nextMonthRect.contains(x, y) -> {
                            changeMonth(1)
                            return true
                        }

                        monthClickRect.contains(x, y) -> {
                            isYearlyView = true
                            invalidate()
                            return true
                        }

                        yearClickRect.contains(x, y) -> {
                            showYearPickerDialog()
                            return true
                        }
                    }
                }

                return true
            }

            MotionEvent.ACTION_CANCEL -> return true
        }

        return true
    }

    // ============================================================
    // تغيير الشهر
    // ============================================================

    private fun changeMonth(delta: Int) {
        currentMonth += delta

        if (currentMonth > 11) {
            currentMonth = 0
            currentYear++
        } else if (currentMonth < 0) {
            currentMonth = 11
            currentYear--
        }

        invalidate()
    }

    // ============================================================
    // اختيار السنة
    // ============================================================

    private fun showYearPickerDialog() {
        val startYear = 1900
        val endYear = 2100

        val yearList = (startYear..endYear).map { toAdlamDigits(it) }.toTypedArray()
        val defaultSelectedIndex = (currentYear - startYear).coerceIn(0, yearList.lastIndex)

        AlertDialog.Builder(context)
            .setTitle("𞤅𞤵𞤩𞤮 𞤖𞤭𞤼𞤢𞥄𞤲𞤣𞤫")
            .setSingleChoiceItems(yearList, defaultSelectedIndex) { dialog, which ->
                currentYear = startYear + which
                invalidate()
                dialog.dismiss()
            }
            .setNegativeButton("𞤃𞤢𞤩𞥆𞤵", null)
            .show()
    }
}
