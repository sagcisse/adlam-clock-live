package com.sagcisse.adlamclock

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.RemoteViews
import com.sagcisse.adlamclock.R

class AdlamCalendarWidget : AppWidgetProvider() {

    companion object {

        private const val DEFAULT_WIDTH = 420
        private const val DEFAULT_HEIGHT = 420
        const val ACTION_CYCLE_CALENDAR_THEME = "com.sagcisse.adlamclock.ACTION_CYCLE_CALENDAR_THEME"

        // هيكل الألوان الموحد والمطابق لـ ClockService
        data class ColorTheme(
            val ticks: Int,
            val numbersText: Int,
            val digitalTimeText: Int,
            val infoText: Int,
            val hourMinHand: Int,
            val secondHand: Int,
            val centerCap: Int,
            val background: Int = Color.TRANSPARENT,
            val dialBg: Int = Color.TRANSPARENT,
            val dialBorder: Int = Color.WHITE,
            val widgetBackground: Int = Color.TRANSPARENT,
            val widgetBorder: Int = Color.TRANSPARENT,
            val widgetBorderWidth: Float = 0f,
            val dialFill: Int = Color.TRANSPARENT,
            val isGlassEffect: Boolean = false
        )

        // مطابقة الثيمات الـ 22 الكاملة التابعة للتطبيق
        val themes = listOf(

            // ----------------------------------------------------
            // القسم الأول: ألوان بدون خلفية (شفافة بالكامل)
            // ----------------------------------------------------
            ColorTheme( // 1. أبيض ناصع
                ticks = Color.WHITE,
                numbersText = Color.WHITE,
                digitalTimeText = Color.WHITE,
                infoText = Color.rgb(230, 230, 230),
                hourMinHand = Color.WHITE,
                secondHand = Color.rgb(255, 87, 34),
                centerCap = Color.rgb(255, 87, 34)
            ),
            ColorTheme( // 2. ذهبي ملكي
                ticks = Color.rgb(220, 180, 70),
                numbersText = Color.rgb(245, 220, 140),
                digitalTimeText = Color.rgb(255, 225, 150),
                infoText = Color.rgb(235, 200, 110),
                hourMinHand = Color.rgb(240, 200, 80),
                secondHand = Color.rgb(245, 130, 32),
                centerCap = Color.rgb(245, 130, 32)
            ),
            ColorTheme( // 3. فضي زجاجي
                ticks = Color.rgb(190, 200, 215),
                numbersText = Color.rgb(230, 240, 255),
                digitalTimeText = Color.rgb(230, 240, 255),
                infoText = Color.rgb(190, 205, 220),
                hourMinHand = Color.rgb(220, 230, 245),
                secondHand = Color.rgb(235, 65, 65),
                centerCap = Color.rgb(235, 65, 65)
            ),
            ColorTheme( // 4. أخضر زمردي
                ticks = Color.rgb(0, 230, 118),
                numbersText = Color.rgb(160, 255, 200),
                digitalTimeText = Color.rgb(160, 255, 200),
                infoText = Color.rgb(120, 230, 170),
                hourMinHand = Color.rgb(0, 230, 118),
                secondHand = Color.rgb(255, 215, 0),
                centerCap = Color.rgb(255, 215, 0)
            ),
            ColorTheme( // 5. أزرق سماوي
                ticks = Color.rgb(0, 200, 255),
                numbersText = Color.rgb(180, 235, 255),
                digitalTimeText = Color.rgb(180, 235, 255),
                infoText = Color.rgb(140, 210, 245),
                hourMinHand = Color.rgb(0, 200, 255),
                secondHand = Color.rgb(255, 110, 110),
                centerCap = Color.rgb(255, 110, 110)
            ),
            ColorTheme( // 6. أرجواني فاخر
                ticks = Color.rgb(224, 64, 251),
                numbersText = Color.rgb(245, 180, 255),
                digitalTimeText = Color.rgb(245, 180, 255),
                infoText = Color.rgb(210, 150, 230),
                hourMinHand = Color.rgb(224, 64, 251),
                secondHand = Color.rgb(0, 230, 118),
                centerCap = Color.rgb(0, 230, 118)
            ),
            ColorTheme( // 7. أحمر مرجاني
                ticks = Color.rgb(255, 82, 82),
                numbersText = Color.rgb(255, 205, 210),
                digitalTimeText = Color.rgb(255, 205, 210),
                infoText = Color.rgb(240, 160, 165),
                hourMinHand = Color.rgb(255, 82, 82),
                secondHand = Color.rgb(255, 215, 0),
                centerCap = Color.rgb(255, 215, 0)
            ),
            ColorTheme( // 8. أصفر فسفوري
                ticks = Color.rgb(255, 235, 59),
                numbersText = Color.rgb(255, 245, 157),
                digitalTimeText = Color.rgb(255, 245, 157),
                infoText = Color.rgb(230, 220, 130),
                hourMinHand = Color.rgb(255, 235, 59),
                secondHand = Color.rgb(0, 229, 255),
                centerCap = Color.rgb(0, 229, 255)
            ),
            ColorTheme( // 9. تركواز سيان
                ticks = Color.rgb(24, 255, 255),
                numbersText = Color.rgb(178, 255, 247),
                digitalTimeText = Color.rgb(178, 255, 247),
                infoText = Color.rgb(130, 230, 220),
                hourMinHand = Color.rgb(24, 255, 255),
                secondHand = Color.rgb(255, 64, 129),
                centerCap = Color.rgb(255, 64, 129)
            ),
            ColorTheme( // 10. برتقالي دافئ
                ticks = Color.rgb(255, 152, 0),
                numbersText = Color.rgb(255, 224, 178),
                digitalTimeText = Color.rgb(255, 224, 178),
                infoText = Color.rgb(230, 180, 140),
                hourMinHand = Color.rgb(255, 152, 0),
                secondHand = Color.rgb(0, 230, 118),
                centerCap = Color.rgb(0, 230, 118)
            ),

            // ----------------------------------------------------
            // القسم الثاني: ألوان صلبة (Solid Colors مع خلفية وإطار)
            // ----------------------------------------------------
            ColorTheme( // 11. أسود ملكي صلب
                ticks = Color.rgb(220, 220, 220),
                numbersText = Color.WHITE,
                digitalTimeText = Color.WHITE,
                infoText = Color.rgb(190, 190, 190),
                hourMinHand = Color.WHITE,
                secondHand = Color.rgb(255, 65, 65),
                centerCap = Color.rgb(255, 65, 65),
                widgetBackground = Color.BLACK,
                widgetBorder = Color.rgb(120, 120, 120),
                widgetBorderWidth = 3f,
                dialFill = Color.rgb(15, 15, 15)
            ),
            ColorTheme( // 12. نيون أخضر صلب
                ticks = Color.rgb(0, 255, 145),
                numbersText = Color.rgb(80, 190, 255),
                digitalTimeText = Color.rgb(145, 225, 255),
                infoText = Color.rgb(175, 235, 255),
                hourMinHand = Color.rgb(95, 205, 255),
                secondHand = Color.rgb(255, 220, 0),
                centerCap = Color.rgb(255, 220, 0),
                widgetBackground = Color.rgb(20, 32, 28),
                widgetBorder = Color.rgb(0, 255, 145),
                widgetBorderWidth = 3.5f,
                dialFill = Color.rgb(15, 38, 30)
            ),
            ColorTheme( // 13. أزرق صلب
                ticks = Color.rgb(70, 180, 255),
                numbersText = Color.WHITE,
                digitalTimeText = Color.rgb(190, 235, 255),
                infoText = Color.rgb(160, 215, 255),
                hourMinHand = Color.WHITE,
                secondHand = Color.rgb(255, 215, 0),
                centerCap = Color.rgb(255, 215, 0),
                widgetBackground = Color.rgb(5, 30, 65),
                widgetBorder = Color.rgb(70, 180, 255),
                widgetBorderWidth = 3.5f,
                dialFill = Color.rgb(8, 40, 85)
            ),
            ColorTheme( // 14. أحمر صلب
                ticks = Color.rgb(255, 80, 80),
                numbersText = Color.rgb(255, 225, 225),
                digitalTimeText = Color.rgb(255, 205, 205),
                infoText = Color.rgb(245, 170, 170),
                hourMinHand = Color.WHITE,
                secondHand = Color.rgb(255, 220, 0),
                centerCap = Color.rgb(255, 220, 0),
                widgetBackground = Color.rgb(55, 8, 8),
                widgetBorder = Color.rgb(255, 80, 80),
                widgetBorderWidth = 3.5f,
                dialFill = Color.rgb(75, 10, 10)
            ),
            ColorTheme( // 15. بنفسجي صلب
                ticks = Color.rgb(210, 100, 255),
                numbersText = Color.rgb(245, 220, 255),
                digitalTimeText = Color.rgb(235, 200, 255),
                infoText = Color.rgb(205, 165, 235),
                hourMinHand = Color.WHITE,
                secondHand = Color.rgb(255, 220, 0),
                centerCap = Color.rgb(255, 220, 0),
                widgetBackground = Color.rgb(30, 8, 48),
                widgetBorder = Color.rgb(210, 100, 255),
                widgetBorderWidth = 3.5f,
                dialFill = Color.rgb(45, 10, 70)
            ),
            ColorTheme( // 16. برتقالي صلب
                ticks = Color.rgb(255, 155, 35),
                numbersText = Color.rgb(255, 240, 210),
                digitalTimeText = Color.rgb(255, 225, 175),
                infoText = Color.rgb(240, 190, 130),
                hourMinHand = Color.WHITE,
                secondHand = Color.rgb(70, 230, 130),
                centerCap = Color.rgb(70, 230, 130),
                widgetBackground = Color.rgb(50, 20, 5),
                widgetBorder = Color.rgb(255, 155, 35),
                widgetBorderWidth = 3.5f,
                dialFill = Color.rgb(70, 28, 7)
            ),

            // ----------------------------------------------------
            // القسم الثالث: ألوان شبه شفافة (Semi-Transparent)
            // ----------------------------------------------------
            ColorTheme( // 17. أسود شبه شفاف (Translucent Black)
                ticks = Color.WHITE,
                numbersText = Color.WHITE,
                digitalTimeText = Color.WHITE,
                infoText = Color.rgb(220, 220, 220),
                hourMinHand = Color.WHITE,
                secondHand = Color.rgb(255, 87, 34),
                centerCap = Color.rgb(255, 87, 34),
                widgetBackground = Color.argb(160, 0, 0, 0),
                widgetBorder = Color.argb(120, 255, 255, 255),
                widgetBorderWidth = 2f,
                dialFill = Color.argb(100, 20, 20, 20)
            ),
            ColorTheme( // 18. أزرق شبه شفاف
                ticks = Color.rgb(100, 200, 255),
                numbersText = Color.WHITE,
                digitalTimeText = Color.rgb(210, 240, 255),
                infoText = Color.rgb(170, 225, 255),
                hourMinHand = Color.WHITE,
                secondHand = Color.rgb(255, 215, 0),
                centerCap = Color.rgb(255, 215, 0),
                widgetBackground = Color.argb(150, 10, 30, 60),
                widgetBorder = Color.argb(180, 70, 180, 255),
                widgetBorderWidth = 2.5f,
                dialFill = Color.argb(100, 15, 45, 85)
            ),
            ColorTheme( // 19. أخضر شبه شفاف
                ticks = Color.rgb(80, 255, 160),
                numbersText = Color.rgb(230, 255, 240),
                digitalTimeText = Color.rgb(190, 255, 220),
                infoText = Color.rgb(150, 240, 190),
                hourMinHand = Color.WHITE,
                secondHand = Color.rgb(255, 215, 0),
                centerCap = Color.rgb(255, 215, 0),
                widgetBackground = Color.argb(150, 10, 50, 30),
                widgetBorder = Color.argb(180, 80, 255, 160),
                widgetBorderWidth = 2.5f,
                dialFill = Color.argb(100, 15, 70, 40)
            ),

            // ----------------------------------------------------
            // القسم الرابع: النمط الزجاجي الذكي (Smart Glassmorphism)
            // ----------------------------------------------------
            ColorTheme( // 20. زجاجي كريستالي ناصع (Glass Light)
                ticks = Color.WHITE,
                numbersText = Color.WHITE,
                digitalTimeText = Color.WHITE,
                infoText = Color.rgb(230, 240, 255),
                hourMinHand = Color.WHITE,
                secondHand = Color.rgb(255, 80, 80),
                centerCap = Color.rgb(255, 80, 80),
                widgetBackground = Color.argb(70, 255, 255, 255),
                widgetBorder = Color.argb(160, 255, 255, 255),
                widgetBorderWidth = 2.5f,
                dialFill = Color.argb(40, 255, 255, 255),
                isGlassEffect = true
            ),
            ColorTheme( // 21. زجاجي داكن ذكي (Glass Dark)
                ticks = Color.rgb(220, 230, 245),
                numbersText = Color.WHITE,
                digitalTimeText = Color.WHITE,
                infoText = Color.rgb(200, 215, 235),
                hourMinHand = Color.WHITE,
                secondHand = Color.rgb(0, 230, 118),
                centerCap = Color.rgb(0, 230, 118),
                widgetBackground = Color.argb(120, 20, 25, 35),
                widgetBorder = Color.argb(140, 255, 255, 255),
                widgetBorderWidth = 2.5f,
                dialFill = Color.argb(60, 30, 40, 55),
                isGlassEffect = true
            ),
            ColorTheme( // 22. زجاجي أزرق ذكي (Glass Neon Blue)
                ticks = Color.rgb(0, 229, 255),
                numbersText = Color.rgb(220, 250, 255),
                digitalTimeText = Color.rgb(180, 245, 255),
                infoText = Color.rgb(140, 220, 245),
                hourMinHand = Color.WHITE,
                secondHand = Color.rgb(255, 215, 0),
                centerCap = Color.rgb(255, 215, 0),
                widgetBackground = Color.argb(100, 10, 40, 70),
                widgetBorder = Color.argb(180, 0, 229, 255),
                widgetBorderWidth = 3f,
                dialFill = Color.argb(50, 0, 150, 220),
                isGlassEffect = true
            )
        )

        // جلب الثيم الخاص بهذا الويدجت للتقويم
        fun getThemeIndex(context: Context, appWidgetId: Int): Int {
            val prefs = context.getSharedPreferences("adlam_clock", Context.MODE_PRIVATE)
            return prefs.getInt("calendar_theme_index_$appWidgetId", 0).coerceIn(0, themes.lastIndex)
        }

        // تغيير الثيم وحفظه لكل ويدجت
        fun cycleThemeIndex(context: Context, appWidgetId: Int): Int {
            if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) return 0
            val prefs = context.getSharedPreferences("adlam_clock", Context.MODE_PRIVATE)
            val next = (getThemeIndex(context, appWidgetId) + 1) % themes.size
            prefs.edit().putInt("calendar_theme_index_$appWidgetId", next).apply()
            return next
        }

        // ========================================================
        // تحديث Widget واحد بناءً على أبعاده الحقيقية
        // ========================================================

        fun updateWidget(
            context: Context,
            manager: AppWidgetManager,
            appWidgetId: Int
        ) {
            try {
                val options = manager.getAppWidgetOptions(appWidgetId)
                val density = context.resources.displayMetrics.density

                val minWidthDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)
                val minHeightDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT)

                val widthPx = if (minWidthDp > 0) (minWidthDp * density).toInt() else DEFAULT_WIDTH
                val heightPx = if (minHeightDp > 0) (minHeightDp * density).toInt() else DEFAULT_HEIGHT

                val bitmap = createCalendarBitmap(
                    context,
                    widthPx,
                    heightPx,
                    appWidgetId
                )

                val views = RemoteViews(
                    context.packageName,
                    R.layout.adlam_calendar_widget
                )

                views.setImageViewBitmap(
                    R.id.calendar_widget_image,
                    bitmap
                )

                // عند الضغط يتم تغيير لون/ثيم التقويم لهذا الويدجت
                val intent = Intent(context, AdlamCalendarWidget::class.java).apply {
                    action = ACTION_CYCLE_CALENDAR_THEME
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
                }

                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    appWidgetId,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                views.setOnClickPendingIntent(
                    R.id.calendar_widget_image,
                    pendingIntent
                )

                manager.updateAppWidget(
                    appWidgetId,
                    views
                )

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // ========================================================
        // تحديث جميع Widgets
        // ========================================================

        fun updateAll(context: Context) {
            try {
                val manager = AppWidgetManager.getInstance(context)
                val component = ComponentName(context, AdlamCalendarWidget::class.java)
                val ids = manager.getAppWidgetIds(component)

                for (id in ids) {
                    updateWidget(context, manager, id)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // ========================================================
        // إنشاء صورة التقويم بالأبعاد الديناميكية مع الألوان
        // ========================================================

        private fun createCalendarBitmap(
            context: Context,
            width: Int,
            height: Int,
            appWidgetId: Int
        ): Bitmap {
            val safeWidth = width.coerceAtLeast(100)
            val safeHeight = height.coerceAtLeast(100)

            val bitmap = Bitmap.createBitmap(
                safeWidth,
                safeHeight,
                Bitmap.Config.ARGB_8888
            )

            val canvas = Canvas(bitmap)
            val calendarView = FulfuldeCalendar(context)

            // التعديل هنا: تطبيق ألوان الثيم المحدد مباشرة بدون Reflection
            val currentTheme = themes[getThemeIndex(context, appWidgetId)]
            calendarView.setTheme(currentTheme)

            val widthSpec = View.MeasureSpec.makeMeasureSpec(
                safeWidth,
                View.MeasureSpec.EXACTLY
            )

            val heightSpec = View.MeasureSpec.makeMeasureSpec(
                safeHeight,
                View.MeasureSpec.EXACTLY
            )

            calendarView.measure(widthSpec, heightSpec)
            calendarView.layout(0, 0, safeWidth, safeHeight)

            calendarView.draw(canvas)

            return bitmap
        }
    }

    // ============================================================
    // عند تحديث Widget
    // ============================================================

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId)
        }
    }

    // ============================================================
    // عند تغيير حجم Widget بواسطة المستخدم على الشاشة
    // ============================================================

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        updateWidget(context, appWidgetManager, appWidgetId)
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        updateAll(context)
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)

        when (intent.action) {
            ACTION_CYCLE_CALENDAR_THEME -> {
                val appWidgetId = intent.getIntExtra(
                    AppWidgetManager.EXTRA_APPWIDGET_ID,
                    AppWidgetManager.INVALID_APPWIDGET_ID
                )
                if (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                    cycleThemeIndex(context, appWidgetId)
                    val manager = AppWidgetManager.getInstance(context)
                    updateWidget(context, manager, appWidgetId)
                }
            }
            AppWidgetManager.ACTION_APPWIDGET_UPDATE,
            AppWidgetManager.ACTION_APPWIDGET_OPTIONS_CHANGED -> {
                updateAll(context)
            }
        }
    }
}
