package com.sagcisse.adlamclock

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Build

class AdlamClockWidget : AppWidgetProvider() {

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        startClockService(context)
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        // رسم الساعة فوراً بشكل مباشر لضمان عدم ظهور الأداة فارغة
        for (appWidgetId in appWidgetIds) {
            ClockService.updateWidgetDirectly(context, appWidgetManager, appWidgetId)
        }
        // تشغيل الخدمة للثواني
        startClockService(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: android.os.Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        // تحديث الرسم فوراً عند ضبط أو تغيير حجم الأداة (مثلاً من 2x2 إلى 1x1)
        ClockService.updateWidgetDirectly(context, appWidgetManager, appWidgetId)
    }

    override fun onDisabled(context: Context) {
        val intent = Intent(context, ClockService::class.java)
        context.stopService(intent)
        super.onDisabled(context)
    }

    private fun startClockService(context: Context) {
        try {
            val intent = Intent(context, ClockService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
