package com.sagcisse.adlamclock

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Build

class AdlamDigitalClockWidget : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        // رسم الـWidgets فور إضافتها
        for (appWidgetId in appWidgetIds) {
            ClockService.updateDigitalWidgetDirectly(
                context,
                appWidgetManager,
                appWidgetId
            )
        }

        // تشغيل خدمة الساعة للتحديث كل ثانية
        startClockService(context)
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        startClockService(context)
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)

        // لا نوقف الخدمة هنا، لأن الساعة التناظرية
        // قد تكون موجودة أيضًا.
    }

    override fun onReceive(
        context: Context,
        intent: Intent
    ) {
        super.onReceive(context, intent)

        when (intent.action) {

            AppWidgetManager.ACTION_APPWIDGET_UPDATE,
            AppWidgetManager.ACTION_APPWIDGET_OPTIONS_CHANGED -> {

                val manager =
                    AppWidgetManager.getInstance(context)

                val component =
                    android.content.ComponentName(
                        context,
                        AdlamDigitalClockWidget::class.java
                    )

                val ids =
                    manager.getAppWidgetIds(component)

                for (id in ids) {
                    ClockService.updateDigitalWidgetDirectly(
                        context,
                        manager,
                        id
                    )
                }

                startClockService(context)
            }
        }
    }

    private fun startClockService(context: Context) {

        try {

            val intent =
                Intent(
                    context,
                    ClockService::class.java
                )

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                context.startForegroundService(intent)

            } else {

                context.startService(intent)
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}