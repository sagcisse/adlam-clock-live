package com.sagcisse.adlamclock

import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class WallpaperGalleryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wallpaper_gallery)

        val txtTitle = findViewById<TextView>(R.id.txtTitle)
        val font = FontLoader.getTypeface(this) ?: Typeface.DEFAULT
        txtTitle.typeface = font

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewWallpapers)
        recyclerView.layoutManager = GridLayoutManager(this, 3)

        // جلب الصور n1 إلى n13 فقط دون إضافة الخيار المجهول (0)
        val wallList = mutableListOf<Int>()
        for (i in 1..13) {
            val resId = resources.getIdentifier("n$i", "drawable", packageName)
            if (resId != 0) {
                wallList.add(resId)
            }
        }

        val prefs = getSharedPreferences("adlam_clock_prefs", Context.MODE_PRIVATE)
        val currentSelected = prefs.getInt("selected_bg_res_id", 0)

        val adapter = WallpaperAdapter(wallList, currentSelected)
        recyclerView.adapter = adapter
    }
}
